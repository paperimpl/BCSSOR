/*******************************************************************************\

	smo_settings.c in Sequential Minimal Optimization ver2.0
	
	creates a smo_Settings from def_Settings.
			
	Chu Wei Copyright(C) National Univeristy of Singapore
	Create on Jan. 16 2000 at Control Lab of Mechanical Engineering 
	Update on Aug. 24 2001 

\*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <sys/types.h> 
#include <sys/timeb.h>
#include "smo.h"

/*******************************************************************************\

	smo_Settings * Create_smo_Settings ( def_Settings * setting ) 
	
	purpose: create and initialize the smo_Settings structure from def_Settings
			call standard SMO to initialize alphas.	
	input:  the pointer to the structure of def_Settings
	output: the pointer to the smo_Settings structure

\*******************************************************************************/

smo_Settings * Create_smo_Settings ( def_Settings * settings )
{
	smo_Settings * psetting = NULL ;
	long unsigned int dim = 0 ,loop=0,loop1;
	long unsigned int i, sz ;
	double temp = 0 ;
	char buf[LENGTH] ;
	FILE * fid ;
	
	if (NULL == settings)
		return NULL ;

	if (NULL != (psetting = (smo_Settings *)(malloc(sizeof(smo_Settings))))) 	
	{
		dim = settings->pairs.dimen ;


		psetting->eps = EPS ;
		psetting->tol = TOL ;		
		psetting->p = P ;
		psetting->kappa=settings->kappa;
		psetting->kernel = KERNEL ;
		psetting->testerror = 0 ;
		psetting->testrate = 0 ;

		psetting->ij_low = NULL ; 
		psetting->ij_up = NULL ;
		psetting->bj_low = NULL ;
		psetting->bj_up = NULL ;
		psetting->biasj = NULL ;
		if (ORDINAL == settings->pairs.datatype)
		{
			psetting->ij_low = (long unsigned int *) malloc((settings->pairs.classes-1)*sizeof(long unsigned int)) ;
			psetting->ij_up = (long unsigned int *) malloc((settings->pairs.classes-1)*sizeof(long unsigned int)) ;
			psetting->bj_low = (double *) malloc((settings->pairs.classes-1)*sizeof(double)) ;
			psetting->bj_up = (double *) malloc((settings->pairs.classes-1)*sizeof(double)) ;
			psetting->biasj = (double *) malloc((settings->pairs.classes-1)*sizeof(double)) ;
			psetting->mu = (double *) calloc((settings->pairs.classes-1),sizeof(double)) ;
			psetting->bmu_low = (double *) malloc((settings->pairs.classes-1)*sizeof(double)) ;
			psetting->bmu_up = (double *) malloc((settings->pairs.classes-1)*sizeof(double)) ;
			psetting->imu_low = (long unsigned int *) malloc((settings->pairs.classes-1)*sizeof(long unsigned int)) ;
			psetting->imu_up = (long unsigned int *) malloc((settings->pairs.classes-1)*sizeof(long unsigned int)) ;
		}
			
		psetting->duration = 0 ;

		psetting->alpha = NULL ;
		psetting->inputfile = NULL ;

		Create_Cache_List( &(psetting->io_cache) ) ;
		psetting->pairs = &(settings->pairs) ;
		
		psetting->cache_size = psetting->pairs->count ;
		psetting->cacheall = FALSE ;		
		psetting->ardon = settings->ardon ;
		psetting->vc1 = settings->vc1 ;
		psetting->vc2 = settings->vc1*settings->traindata.count/settings->testdata.count;
		psetting->testerror = 0 ;
		psetting->testrate = 0 ;
		psetting->traindata=&settings->traindata;
		psetting->testdata=&settings->testdata;
		psetting->pairs->truecount=psetting->traindata->count+2*psetting->testdata->count;
		psetting->pairs->workingcount=psetting->traindata->count;
		psetting->first=TRUE;
		psetting->clean=TRUE;
		psetting->threshold=settings->threshold;
		
		psetting->GBC=(double **) malloc((psetting->testdata->count+psetting->traindata->count)*sizeof(double *)) ;
		for(loop=0;loop<psetting->testdata->count+psetting->traindata->count;loop++)
			psetting->GBC[loop]=(double *) malloc((psetting->pairs->classes-1)*sizeof(double ));
		for(loop=0;loop<psetting->testdata->count+psetting->traindata->count;loop++)
			for(loop1=0;loop1<psetting->pairs->classes-1;loop1++)
			{
				psetting->GBC[loop][loop1]=1;
			}
		
		psetting->BCn=(int *) malloc((psetting->pairs->classes-1)*sizeof(int ));
		psetting->BCu=(int *) malloc((psetting->pairs->classes-1)*sizeof(int ));
		for(loop1=0;loop1<psetting->pairs->classes-1;loop1++)
		{
			psetting->BCn[loop1]=psetting->traindata->count;
			psetting->BCu[loop1]=psetting->testdata->count;
		}
		// save the name of input file
		if ( NULL == (psetting->inputfile = strdup( INPUTFILE )) )
		{
			Clear_smo_Settings( psetting ) ;
			return NULL ;
		}
		// init Alpha Matrix which is hybrid hashing table
		if ( NULL == (psetting->alpha = Create_Alphas(psetting,settings->traindata.count,settings->testdata.count) ) )
		{
			printf( "Alphas can not be created.\n" );
			Clear_smo_Settings( psetting ) ;
			return NULL ;
		}
		psetting->cacheall = TRUE ;
	}
	return psetting ; 
}

/*******************************************************************************\

	void * Clear_Smo_Settings ( smo_Settings * psetting ) 
	
	Clear the smo_Settings structure, including its Alphas Structure & Io_CACHE
	input:  the pointer to the smo_Settings structure
	output: none 

\*******************************************************************************/

void Clear_smo_Settings( smo_Settings * settings )
{
	if ( NULL != settings )
	{
		if (NULL != settings->ard)
			free(settings->ard) ;
		if (ORDINAL == settings->pairs->datatype)
		{
			if (NULL != settings->ij_low)
				free(settings->ij_low) ;
			if (NULL != settings->ij_up)
				free(settings->ij_up) ;
			if (NULL != settings->bj_low)
				free(settings->bj_low) ;
			if (NULL != settings->bj_up)
				free(settings->bj_up) ;
			if (NULL != settings->biasj)
				free(settings->biasj) ;
		}
		Clear_Cache_List( &(Io_CACHE) ) ;
		Clear_Alphas( settings ) ;
		if ( NULL != INPUTFILE )
			free( INPUTFILE ) ;
		free ( settings ) ;
		settings = NULL ;
	}
} 
// the end of smo_settings.c
