/*******************************************************************************\

	main.c in Sequential Minimal Optimization ver2.0
		
	entry function.
		
	Chu Wei Copyright(C) National Univeristy of Singapore
	Create on Jan. 16 2000 at Control Lab of Mechanical Engineering 
	Update on Aug. 23 2001 

\*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <limits.h>
#include <math.h>
#include <time.h>
#include "smo.h"

int main( int argc, char * argv[])
{
	def_Settings * defsetting = NULL ;
	smo_Settings * smosetting = NULL ;
	Data_Node * pair = NULL ;
	double * point;
	int loop;
	//Data_Node * node ;
	char buf[LENGTH] ;
	unsigned int sz = 0;
	unsigned int index = 0 ;
	double parameter = 0 ;
	//double * guess ;
	FILE * log ; 
	if ( 1 == argc || NULL == (defsetting = Create_def_Settings(argv[--argc])) )
	{
		// display help	
		printf("\nUsage:  svor [-v] [...] [-R r] file \n\n") ;
		printf("  file   specifies the file containing training samples.\n") ;
		printf("  -L     use imbalanced Linear kernel (default Gaussian kernel).\n") ;
		printf("  -P  p  use Polynomial kernel with order p (default Gaussian kernel).\n") ;
		printf("  -G  kappa  use Gaussian kernel with g (default Gaussian kernel).\n") ;	
		printf("  -i     normalize the training inputs.\n") ;			
		printf("  -T  t  set Tolerance at t (default 0.001).\n") ;		
		printf("  -t  threshold  set threshold .\n") ;		
		printf("  -C  vc1  (default 10) \n") ;	
		printf("  -c  vc2  (default 5) \n") ;	
		printf("\n") ;
		if (NULL !=defsetting)
			Clear_def_Settings( defsetting ) ;
		system("pause");
		return 0;
	}
	else
	{
		if (argc>1)
			printf("Options:\n") ;
		do
		{
			strcpy(buf, argv[--argc]) ;
			sz = strlen(buf) ;
			//printf ("%s  %d\n", buf, sz) ;
			if ( '-' == buf[0] )
			{				
				for (index = 1 ; index < sz ; index++)
				{
					switch (buf[index])
					{
					
					case 'L' :
						printf("  - choose Linear kernel.\n") ;
						defsetting->kernel = LINEAR ;						
						break ;
					
					case 'P' :						
						if (parameter >= 1)
						{ 
							defsetting->kernel = POLYNOMIAL ;
							defsetting->p = (unsigned int) parameter ;
							printf("  - choose Polynomial kernel with order %d.\n", defsetting->p) ;
							parameter = 0 ;
						}					
						break ;	
					case 'G' :						
						if (parameter >0)
						{ 
							defsetting->kernel = GAUSSIAN ;
							defsetting->kappa = parameter ;
							printf("  - choose GAUSSIAN kernel with  %f .\n", defsetting->kappa) ;
							parameter = 0 ;
						}					
						break ;	
					case 'i' :
						printf("  - normalize the Inputs in training data.\n") ;
						defsetting->normalized_input = TRUE ;	
						defsetting->pairs.normalized_input = TRUE ;
						break ;
					case 'T' :
						if (parameter>0)
						{
							printf("  - set Tol as %.6f.\n", parameter) ;
							defsetting->tol = parameter ;
						}
						break ;	
					case 't' :
						if (parameter>0)
						{
							printf("  - set threshold as %.6f.\n", parameter) ;
							defsetting->threshold = parameter ;
						}
						break ;	
					case 'C' :
						if (parameter>0)
						{
							printf("  - set VC1 as %.6f.\n", parameter) ;
							defsetting->vc1 = parameter ;
						}
						break ;	
					case 'c' :
						if (parameter>0)
						{
							printf("  - set VC2 as %.6f.\n", parameter) ;
							defsetting->vc2 = parameter ;
						}
						break ;	
					default :
						if ('-' != buf[index])
							printf("  -%c is invalid.\n", buf[index]) ;
						break ;
					}
				}
			}
			else
				parameter = atof(buf) ;
		}
		while ( argc > 1 ) ;
		printf("\n") ;
	}


	if ( TRUE == Update_def_Settings(defsetting) ) 
	{
		// create smosettings
		printf ("\n\n TESTING on %s... \n", defsetting->testfile ) ;	
		
		// load test data
		if ( FALSE == smo_Loadfile(&(defsetting->testdata), defsetting->testfile, defsetting->traindata.dimen) )
		{
			printf ("No testing data found in the file %s.\n", defsetting->testfile ) ;
			system("pause");
		}
		// calculate the test output
		else
		{
			defsetting->pairs.classes = defsetting->traindata.classes ;	
			defsetting->pairs.dimen = defsetting->traindata.dimen ;
			defsetting->pairs.featuretype = defsetting->traindata.featuretype ;
			defsetting->pairs.datatype = defsetting->traindata.datatype ;
			if(FALSE==Create_pairs(defsetting))
			{
				printf("Create_pairs  failed ");
				system("pause");
				return 0;
			}
			
			tstart() ; //timer on
			smosetting = Create_smo_Settings(defsetting) ; 
			tend() ;
			printf("Create_smo_Settings  spend : %lf s  \n",tval());
			smosetting->pairs = &defsetting->pairs ; 
			smosetting->traindata = &defsetting->traindata ; 
			smosetting->testdata = &defsetting->testdata ; 
			while(smo_routine (smosetting)) ;
			printf("all smo spend : %lf s  \n",smosetting->duration);
			scanf("%d",&loop);

			//Clear_smo_Settings( smosetting ) ;
		}

	}
	// free memory then exit
	//Clear_def_Settings( defsetting ) ;
	system("pause");
	return 0;
}
//end of main.c 
