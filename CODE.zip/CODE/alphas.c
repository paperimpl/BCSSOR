/*******************************************************************************\

	alphas.c in Sequential Minimal Optimization ver2.0
		
	implements initialization for alphas matrix.
		
	Chu Wei Copyright(C) University College London
	Create on Jan. 16 2000 at Control Lab of Mechanical Engineering 
	Update on May. 30 2004 

\*******************************************************************************/

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <limits.h>
#include "smo.h"


/*******************************************************************************\

	Alphas * Create_Alphas ( smo_Settings * settings )
	
	create and initialize a structure matrix of Alphas from Data_List 
	input:  the pointer to smo_Settings
	output: the pointer to the head of the structure matrix for alphas

\*******************************************************************************/

Alphas * Create_Alphas ( smo_Settings * settings ,unsigned int trainnum,unsigned int testnum) 
{
	Data_Node * pair = NULL ; 	
	Alphas * alpha = NULL ;
	Alphas * alphas = NULL ;
	Data_List * pairs = NULL ;
	long int  i = 0, j,j2,j3,loop,k,k2;
	
	if ( NULL == settings )
	{
		printf("\nFATAL ERROR : input is NULL in Create_Alphas.\n") ;
		return NULL ;
	}

	if ( NULL == (pairs = settings->pairs) )
	{
		printf("\nFATAL ERROR : data list is NULL in Create_Alphas.\n") ;
		return NULL ;
	}

	if ( TRUE == Is_Data_Empty( pairs ) || pairs->count < MINNUM )
	{ 
		printf( "\nFATAL ERROR : Data_List have not be initialized.\n") ;
		return  NULL ;
	}

	if ( NULL == (alphas = (Alphas *) malloc( pairs->count*sizeof(Alphas) )) )
	{
		printf( "\nFATAL ERROR : fail to malloc Alphas block.\n") ;
		system("pause");
		exit(1) ;		
	}

	pair = pairs->front ;
	while ( pair != NULL )
	{		
		alpha = alphas + i ;
		i += 1 ;	
		alpha->f_cache = 0 ;
		alpha->pair = pair ;
		if(i<=trainnum)
			alpha->vc=settings->vc1;
		else if(i>=(trainnum+2*testnum+1))
			alpha->vc=INT_MAX;
		else
			alpha->vc=settings->vc2;
		alpha->kernel = NULL ;
		if(i<=(trainnum+testnum)||i>=(trainnum+2*testnum+1))
		{
			if(i>=(trainnum+2*testnum+1))
				alpha->kernel = (double *) malloc(i*sizeof(double)) ;
			else
				alpha->kernel = (double *) malloc(i*sizeof(double)) ;
			if ( NULL == alpha->kernel )
			{
				printf("Fatal Error : fail to malloc kernel cache.\n") ;
				system("pause");
				exit(1) ;
			}
			else
			{
				// initial the kernel matrix cache
				if(i<=settings->pairs->truecount)
				{
					#pragma omp parallel for private(j) num_threads(omp_get_max_threads() - 1)
					for (j=0 ; j<i ; j++)
					{
						alpha->kernel[j] = Calc_Kernel(alpha, alphas+j, settings) ;	
						//printf("%d  \n",omp_get_thread_num());
					}
					
				}
			
			}
		}
		alpha->alpha = (double *) calloc(settings->pairs->classes-1,sizeof(double)) ;
		alpha->y = (double *) calloc(settings->pairs->classes-1,sizeof(double)) ;
		alpha->beta = (double *) calloc(settings->pairs->classes-1,sizeof(double)) ;
		alpha->setname = (Set_Name * ) malloc((settings->pairs->classes-1)*sizeof(Set_Name)) ;	
		if (NULL == alpha->alpha || NULL == alpha->setname || NULL == alpha->y || NULL == alpha->beta)
		{
			printf("\nFatal Error : fail to malloc alpha \n") ;
			system("pause");
			exit(1) ;
		}
		for (j=0;j<settings->pairs->classes-1;j++)
		{
			alpha->setname[j] = Get_Ordinal_Label (alpha, j+1, settings) ;
			if(alpha->pair->target>j+1)
				alpha->y[j]=1;
			else
				alpha->y[j]=-1;
		}
			
		
		alpha->cache = NULL ;
		pair = pair->next ;
	}
	settings->cacheall=TRUE;
	settings->alpha=alphas;
	for(loop=settings->pairs->truecount;loop<settings->pairs->count;loop++)
	{
		k=loop-settings->pairs->truecount;
		alpha=alphas+loop;
		for(j=0;j<loop+1;j++)
			alpha->kernel[j]=0;
		for(j=0;j<loop+1;j++)
		{
			if(j<settings->pairs->truecount)
			{
				for(j2=trainnum;j2<trainnum+testnum;j2++)
				{
					alpha->kernel[j]+=settings->GBC[j2][k]*Calc_Kernel(alphas+j,alphas+j2,settings);
				}
				alpha->kernel[j]/=settings->BCu[k];
			}
			else
			{
				k2=j-settings->pairs->truecount;
				for(j2=trainnum;j2<trainnum+testnum;j2++)
					for(j3=trainnum;j3<trainnum+testnum;j3++)
						alpha->kernel[j]+=settings->GBC[j2][k]*settings->GBC[j3][k2]*Calc_Kernel(alphas+j2,alphas+j3,settings);
				alpha->kernel[j]/=settings->BCu[k]*settings->BCu[k2];
			}
		}

	}
	return alphas ;
} // end of Create_Alphas


/*******************************************************************************\

	BOOL Clear_Alphas ( smo_Settings * settings )
	
	clear the structure matrix of Alphas from smo_Settings
	input:  the pointer to smo_Settings
	output: TRUE or FALSE

\*******************************************************************************/

BOOL Clear_Alphas ( smo_Settings * settings )
{
	Alphas * alpha ;
	unsigned int  i = 0 ;
	Data_List * pairs = NULL ;	
	
	if ( NULL == settings )
	{
		printf("\nFATAL ERROR : input is NULL in Create_Alphas.\n") ;
		return FALSE ;
	}

	if ( NULL == (pairs = settings->pairs) )
	{
		printf("\nFATAL ERROR : input is NULL in Create_Alphas.\n") ;
		return FALSE ;
	}

	for (i=0;i<settings->pairs->count;i++)
	{
		alpha = ALPHA + i ;
		if (NULL != alpha->setname)
			free(alpha->setname) ;
		if (NULL != alpha->alpha)
			free(alpha->alpha) ;
		if (NULL != alpha->kernel)
			free(alpha->kernel) ;
	}
	free(ALPHA) ;
	return TRUE ;

} // end of Clear_Alphas

/*******************************************************************************\

	BOOL Clean_Alphas ( Alphas *, smo_Settings * settings )
	
	set all the elements in the matrix to be the default values 
	input:  the pointer to the head of Alphas matrix and the pointer to smo_Settings 
	output: TRUE or FALSE

\*******************************************************************************/

BOOL Clean_Alphas ( Alphas * alphas, smo_Settings * settings )
{
	Alphas * alpha ;
	unsigned int  i = 0, j ;
	Data_Node * node = NULL ;
	Data_List * pairs = NULL ;	
	
	if ( NULL == alphas || NULL == settings )
	{
		printf("\nFATAL ERROR : input is NULL in Create_Alphas.\n") ;
		return FALSE ;
	}

	if ( NULL == (pairs = settings->pairs) )
	{
		printf("\nFATAL ERROR : input is NULL in Create_Alphas.\n") ;
		return FALSE ;
	}
	
	node = pairs->front ;
	while (NULL != node)
	{		
		alpha = alphas + i ;	
		i += 1 ;
		alpha->f_cache = 0 ;
		for (j=0;j<settings->pairs->classes-1;j++)
		{
			alpha->alpha[j] = 0 ;	
			alpha->setname[j] = Get_Ordinal_Label (alpha, j+1, settings) ;
		}
		alpha->cache = NULL ; // clear the reference to Io_Cache here
		alpha->pair = node ;			
		node = node->next ;
	}
	return TRUE ;

} // end of Clean_Alphas

/*******************************************************************************\

	BOOL Check_Alphas ( Alphas *, smo_Settings * settings )
	
	check the validation of the Alphas matrix and then itialize the bias terms 
	input:  the pointer to the head of Alphas matrix and the pointer to smo_Settings 
	output: TRUE or FALSE

\*******************************************************************************/

BOOL Check_Alphas ( Alphas * alphas, smo_Settings * settings )
{
	Alphas * alpha ;
	unsigned int loop = 0 ,loop1=0;
	Data_Node * node = NULL ;
	Data_List * pairs = NULL ;
	long int i = 0 ; 
	unsigned int j ;

	if ( NULL == alphas || NULL == settings )
	{
		printf("\nFATAL ERROR : input is NULL in Create_Alphas.\n") ;
		return FALSE ;
	}

	if ( NULL == (pairs = settings->pairs) )
	{
		printf("\nFATAL ERROR : input is NULL in Create_Alphas.\n") ;
		return FALSE ;
	}

	Clear_Cache_List( &(Io_CACHE) ) ;
		
	node = pairs->front ;
	while (NULL != node)
	{		
		alpha = alphas + i ;
		if(i>=settings->pairs->workingcount)
			break;
		for (j=0;j<pairs->classes-1;j++)
		{			

			if((alpha-ALPHA)<(settings->pairs->truecount))
			{
				if (alpha->alpha[j] > alpha->vc)
					alpha->alpha[j] = alpha->vc ;
				else if (alpha->alpha[j] < 0)
					alpha->alpha[j] = 0 ;
			}
			else
			{
				if(j!=(i-settings->pairs->truecount))
					alpha->alpha[j] = 0;
			}

			alpha->setname[j] = Get_Ordinal_Label (alpha, j+1, settings) ; 
		}
		alpha->f_cache = Calculate_Ordinal_Fi(i+1,settings) ;
		alpha->cache = NULL ; // clear the reference to Io_Cache here
		if (alpha->pair != node)
			printf("error in alpha or data list.\n") ;			
		node = node->next ;	
		i += 1 ;

	}
	
	// initial b_up b_low		
	for (loop = 1 ; loop < settings->pairs->classes ; loop ++)
	{
		settings->bj_up[loop-1] = (double)INT_MAX ;
		settings->bj_low[loop-1] = (double)INT_MIN ;
		settings->ij_up[loop-1] = 0 ;
		settings->ij_low[loop-1] = 0 ;
	}
	// create Io_cache 
	i = 0 ;
	node = pairs->front ;
	while (NULL != node)
	{
		alpha = alphas + i ;
		if(i>=settings->pairs->workingcount)
			break;
		i += 1 ;
		if (TRUE == Is_Io(alpha,settings))
		{
			//alpha->f_cache = Calculate_Ordinal_Fi(i, settings) ;
			Add_Cache_Node(&settings->io_cache, alpha) ;			
		}
		for (loop = 0 ; loop < pairs->classes-1 ; loop ++)
		{
			if (alpha->pair->target > (loop+1.5) )
			{
				//lower
				if (alpha->setname[loop]==Io_b || alpha->setname[loop]==I_One)
				{
					if (alpha->f_cache-1<settings->bj_up[loop])
					{
						settings->bj_up[loop] = alpha->f_cache-1 ;
						settings->ij_up[loop] = alpha - ALPHA + 1 ;
					}
				}
				if (alpha->setname[loop]==Io_b || alpha->setname[loop]==I_Fou)
				{
					if (alpha->f_cache-1>settings->bj_low[loop])
					{
						settings->bj_low[loop] = alpha->f_cache-1 ;
						settings->ij_low[loop] = alpha - ALPHA + 1 ;
					}
				}
			}
			else
			{
				//upper
				if (alpha->setname[loop]==Io_a || alpha->setname[loop]==I_Thr)
				{
					if (alpha->f_cache+1<settings->bj_up[loop])
					{
						settings->bj_up[loop] = alpha->f_cache+1 ;
						settings->ij_up[loop] = alpha - ALPHA + 1 ;
					}
				}
				if (alpha->setname[loop]==Io_a || alpha->setname[loop]==I_Two)
				{
					if (alpha->f_cache+1>settings->bj_low[loop])
					{
						settings->bj_low[loop] = alpha->f_cache+1 ;
						settings->ij_low[loop] = alpha - ALPHA + 1 ;
					}
				}
			}

		}
		node = node->next ;	
	}

		//for(loop=0;loop<settings->pairs->classes-1;loop++)
		//{
		//	if(settings->ij_low[loop]==0 )
		//	{
		//		for(loop1=loop+1;loop1<settings->pairs->classes-1;loop1++)
		//		{
		//			if(settings->ij_low[loop1]!=0 )
		//			{
		//				settings->ij_low[loop]=settings->ij_low[loop1];
		//				settings->bj_low[loop]=settings->bj_low[loop1];
		//				break;
		//			}
		//		}
		//		if(settings->ij_low[loop]==0 )
		//		{
		//			for(loop1=loop-1;loop1>=0;loop1--)
		//			{
		//				if(settings->ij_low[loop1]!=0 )
		//				{
		//					settings->ij_low[loop]=settings->ij_low[loop1];
		//					settings->bj_low[loop]=settings->bj_low[loop1];
		//					break;
		//				}
		//			}
		//		}

		//	}
		//	if(settings->ij_up[loop]==0 )
		//	{
		//		
		//		for(loop1=loop-1;loop1>=0;loop1--)
		//		{
		//			if(settings->ij_up[loop1]!=0 )
		//			{
		//				settings->ij_up[loop]=settings->ij_up[loop1];
		//				settings->bj_up[loop]=settings->bj_up[loop1];
		//				break;
		//			}
		//		}
		//		if(settings->ij_up[loop]==0 )
		//		{
		//			for(loop1=loop+1;loop1<settings->pairs->classes-1;loop1++)
		//			{
		//				if(settings->ij_up[loop1]!=0 )
		//				{
		//					settings->ij_up[loop]=settings->ij_up[loop1];
		//					settings->bj_up[loop]=settings->bj_up[loop1];
		//					break;
		//				}
		//			}
		//		}
		//	}
		//}
	for(loop=0;loop<settings->pairs->classes-1;loop++)
	{
				//if(settings->ij_low[loop]==0 || settings->ij_up[loop]==0)
				//	printf("");
		if(settings->ij_low[loop]==0 )
		{
			//printf("check alpha  \n");
			settings->ij_low[loop]=settings->ij_up[loop];
			settings->bj_low[loop]=settings->bj_up[loop];
		}
		if(settings->ij_up[loop]==0 )
		{
			//printf("check alpha  \n");
			settings->ij_up[loop]=settings->ij_low[loop];
			settings->bj_up[loop]=settings->bj_low[loop];
		}
	}
	return TRUE ;
} // end of Check_Alphas

// the end of alphas.c
