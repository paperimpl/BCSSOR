#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <sys/types.h> 
#include <sys/timeb.h>
#include "smo.h"
#include<time.h>


unsigned int active_cross_threshold (smo_Settings * settings) 
{
	unsigned int i, j = 0 ;
	double active = 0 ;
	double temp = 0 ; 
	
	if (NULL == settings)
	{
		printf("error in the input pointer.\n") ;
		return j ;
	}
	for (i=1;i<settings->pairs->classes;i++)
	{
		temp = settings->bmu_low[i-1]-settings->bmu_up[i-1] ;
		if (temp>active && temp>TOL)
		{
			active = temp ;		
			j = i ; 
		}
	}
	return j ; // optimal j=0
}
unsigned int active_threshold (smo_Settings * settings) 
{
	unsigned int i, j = 0 ;
	double active = 0 ; 
	double temp = 0 ; 
	
	if (NULL == settings)
	{
		printf("error in the input pointer.\n") ;
		return j ;
	}
	for (i=1;i<settings->pairs->classes;i++)
	{
		temp = settings->bj_low[i-1]-settings->bj_up[i-1] ;
		if (temp>active && temp>TOL)
		{
			active = temp ;			
			j = i ; 
		}
	}
	return j ; // optimal j=0
}

BOOL ordinal_examine_example ( Alphas * alpha, smo_Settings * settings )
{
	BOOL BC=TRUE;
	double zerosample=0,zeronum=0;
	unsigned int j = 0,max,numChanged ,j1,j2;
	unsigned int loop ,loop1;
	long unsigned int i1 = 0 ;
	long unsigned int i2 = 0 ;
	long unsigned int i3 = 0 ;
	float * chooseBC;
	BOOL optimal = TRUE ; 
	Cache_Node * cache = NULL ;
	Alphas * a1,*a2,*a0;
	long unsigned int temp;
	double averagey,averagef,F2=0,F3;

	if ( NULL == alpha || NULL == settings )
		return FALSE ;

	if (ORDINAL != settings->pairs->datatype)
		return FALSE ;

	i2 = alpha - ALPHA + 1 ;


    //calculate F2 if i2 in I_One or not in I_One
	if ( FALSE == Is_Io(alpha,settings) )
	{
		alpha->f_cache = Calculate_Ordinal_Fi(i2, settings) ;
		// update b_low and b_up
		for (loop = 0 ; loop < settings->pairs->classes-1 ; loop ++)
		{
			if (alpha->pair->target > (loop+1) )
			{
				//lower
				if (alpha->setname[loop]==Io_b || alpha->setname[loop]==I_One)
				{
					if (alpha->f_cache-1<=settings->bj_up[loop])
					{
						settings->bj_up[loop] = alpha->f_cache-1 ;
						settings->ij_up[loop] = alpha - ALPHA + 1 ;
					}
				}
				if (alpha->setname[loop]==Io_b || alpha->setname[loop]==I_Fou)
				{
					if (alpha->f_cache-1>=settings->bj_low[loop])
					{
						settings->bj_low[loop] = alpha->f_cache-1 ;
						settings->ij_low[loop] = alpha - ALPHA + 1 ;
					}
				}
			}
			else
			{
				//upper
				if (alpha->setname[loop]==Io_a || alpha->setname[loop]==I_Thr)
				{
					if (alpha->f_cache+1<=settings->bj_up[loop])
					{
						settings->bj_up[loop] = alpha->f_cache+1 ;
						settings->ij_up[loop] = alpha - ALPHA + 1 ;
					}
				}
				if (alpha->setname[loop]==Io_a || alpha->setname[loop]==I_Two)
				{
					if (alpha->f_cache+1>=settings->bj_low[loop])
					{
						settings->bj_low[loop] = alpha->f_cache+1 ;
						settings->ij_low[loop] = alpha - ALPHA + 1 ;
					}
				}
			}
		}
	}
	// update mu_bias
	for (loop = 1; loop < settings->pairs->classes; loop ++)
	{
		settings->bmu_low[loop-1]=settings->bj_low[loop-1] ;
		settings->imu_low[loop-1]=loop ;
		if (loop>1)
		{	
			// b_low^j=max{b_low^j-1,b_low^j}
			if (settings->bmu_low[loop-2]>settings->bmu_low[loop-1])
			{
				settings->bmu_low[loop-1]=settings->bmu_low[loop-2] ;
				settings->imu_low[loop-1]=settings->imu_low[loop-2] ;
			}
		}
	}
	for (loop = settings->pairs->classes-1; loop > 0; loop --)
	{
		settings->bmu_up[loop-1]=settings->bj_up[loop-1] ;
		settings->imu_up[loop-1]=loop ;
		if (loop<settings->pairs->classes-1)
		{
			// b_up^j=min{b_up^j,b_up^j+1}
			if (settings->bmu_up[loop-1]>settings->bmu_up[loop])
			{
				settings->bmu_up[loop-1]=settings->bmu_up[loop] ;
				settings->imu_up[loop-1]=settings->imu_up[loop] ;
			}			
		}
	}
	for (loop = 2; loop < settings->pairs->classes; loop ++)
	{
		if (settings->mu[loop-1]>EPS*EPS) 
		{
			BC=FALSE;
			if (settings->bmu_up[loop-1]>settings->bmu_up[loop-2])
			{
				settings->bmu_up[loop-1]=settings->bmu_up[loop-2] ;
				settings->imu_up[loop-1]=settings->imu_up[loop-2] ;
			}
			if (settings->bmu_low[loop-2]<settings->bmu_low[loop-1])
			{
				settings->bmu_low[loop-2]=settings->bmu_low[loop-1] ;
				settings->imu_low[loop-2]=settings->imu_low[loop-1] ;
			}
		}
	}
	if((alpha-ALPHA)<settings->pairs->truecount)
	{
		// find an index in i_low or i_up, to do joint optimization
		for (loop = 0 ; loop < settings->pairs->classes-1 ; loop ++)
		{
			if (alpha->pair->target > (loop+1) )
			{
				//lower
				if (alpha->setname[loop]==Io_b || alpha->setname[loop]==I_One)
				{
					if ( settings->bmu_low[loop] - (alpha->f_cache-1) > TOL )
					{
						optimal = FALSE ;
						if (settings->bmu_low[loop]-(alpha->f_cache-1)>F2)
						{
							i1 = settings->ij_low[settings->imu_low[loop]-1] ;
							F2 = settings->bmu_low[loop]-(alpha->f_cache-1) ;
							j2 = loop+1 ;
							j1=settings->imu_low[loop];
						}
					}
				}
				if (alpha->setname[loop]==Io_b || alpha->setname[loop]==I_Fou)
				{
					if ( (alpha->f_cache-1) - settings->bmu_up[loop] > TOL )
					{
						optimal = FALSE ;
						if ((alpha->f_cache-1) - settings->bmu_up[loop]>F2)
						{
							i1 = settings->ij_up[settings->imu_up[loop]-1] ;
							F2 = (alpha->f_cache-1) - settings->bmu_up[loop] ;
							j2 = loop+1 ; 
							j1=settings->imu_up[loop];
						}
					}
				}
			}
			else
			{
				//upper
				if (alpha->setname[loop]==Io_a || alpha->setname[loop]==I_Thr)
				{
					if (settings->bmu_low[loop]-(alpha->f_cache+1)>TOL)
					{
						optimal = FALSE ;
						if (settings->bmu_low[loop]-(alpha->f_cache+1)>F2)
						{
							i1 = settings->ij_low[settings->imu_low[loop]-1] ;
							F2 = settings->bmu_low[loop]-(alpha->f_cache+1) ;
							j2 = loop+1 ;
							j1=settings->imu_low[loop];
						}
					}
				}
				if (alpha->setname[loop]==Io_a || alpha->setname[loop]==I_Two)
				{
					if ((alpha->f_cache+1)-settings->bmu_up[loop]>TOL)
					{
						optimal = FALSE ;
						if ((alpha->f_cache+1)-settings->bmu_up[loop]>F2)
						{
							i1 = settings->ij_up[settings->imu_up[loop]-1] ;
							F2 = (alpha->f_cache+1)-settings->bmu_up[loop] ;
							j2 = loop+1 ;
							j1=settings->imu_up[loop];
						}
					}
				}
			}
		}

		if (optimal == FALSE)
		{		
			if(settings->pairs->workingcount<settings->pairs->count)
			{
				if(j1!=j2)
					settings->shringcount-= ordinal_cross_takestep( ALPHA + i1 - 1,j1, ALPHA + i2 - 1, j2 , settings);
				else
					settings->shringcount-=ordinal_takestep( ALPHA + i1 - 1, ALPHA + i2 - 1, j1 , settings);
				return TRUE;
			}
			if(j1!=j2)
			{
				settings->shringcount-= ordinal_cross_takestep( ALPHA + i1 - 1,j1, ALPHA + i2 - 1, j2 , settings);
				return TRUE;
			}
			//else
			//{
			//	settings->shringcount-=ordinal_takestep( ALPHA + i1 - 1, ALPHA + i2 - 1, j1 , settings);
			//	return TRUE;
			//}
			j=j1;
			temp=settings->shringcount;
			a1=ALPHA + i1 - 1;
			a2=ALPHA + i2 - 1;
			a0=ALPHA + settings->pairs->truecount+j-1;
			averagey=settings->sumy[j-1]/settings->BCn[j-1];
			averagef=settings->SumF[j-1]-(settings->bmu_low[j-1]+settings->bmu_up[j-1])/2.0*settings->BCu[j-1];
			averagef=averagef/settings->BCu[j-1];
			if(fabs(averagey-averagef)>0.001&&settings->startBC==TRUE)
			{
				if(fabs(a2->f_cache-a0->f_cache)<fabs(a2->f_cache-a1->f_cache))
					if(!ordinal_takestep( ALPHA + i1 - 1, ALPHA + i2 - 1, j , settings))
						//settings->shringcount-=ordinal_takestep(ALPHA + settings->pairs->truecount+j-1, ALPHA + i2 - 1,j , settings);
						settings->shringcount=settings->shringcount;
					else
						settings->shringcount--;
				else
					if(!ordinal_takestep(ALPHA + settings->pairs->truecount+j-1, ALPHA + i2 - 1,j , settings))
						settings->shringcount-=ordinal_takestep( ALPHA + i1 - 1, ALPHA + i2 - 1, j , settings);
					else
						settings->shringcount--;
			}
			else
				settings->shringcount-=ordinal_takestep( ALPHA + i1 - 1, ALPHA + i2 - 1, j , settings);
			return TRUE;
		}
		return FALSE ;
	}
	else
	{
		i3=-1;
		F2=0;
		F3=0;
		j=0;
		loop=i2 - 1-settings->pairs->truecount;
		zerosample=0;
		zeronum=0;
		i1=settings->pairs->truecount;
		averagey=0;
		averagef=0;
		averagey=settings->sumy[loop]/settings->BCn[loop];
		averagef=0;
		averagef=settings->SumF[loop]-(settings->bmu_low[loop]+settings->bmu_up[loop])/2.0*settings->BCu[loop];
		averagef=averagef/settings->BCu[loop];
		if(fabs(averagey-averagef)>0.001&&settings->startBC==TRUE)
		{		
			settings->shringcount=settings->shringcount-min(settings->pairs->count,1000)/10;
			F2=settings->shringcount;
			optimal = FALSE ;
			chooseBC=(float *)calloc(settings->pairs->truecount,sizeof(float ));
			i1=settings->pairs->truecount;
			while(i1>0)
			{
				chooseBC[i1-1]=fabs((ALPHA + i1 - 1)->f_cache-(ALPHA + i2 - 1)->f_cache);
				i1--;	

			}
			while(settings->shringcount>(F2-3)&&fabs(averagey-averagef)>0.001)
			{
				F3=0;
				i3=-1;
				for(i1=0;i1<settings->pairs->truecount;i1++)
				{
					if(chooseBC[i1]>F3)
					{
						F3=chooseBC[i1];
						i3=i1+1;
					}
				}
				if(i3!=-1)
				{
					if(ordinal_takestep(ALPHA + i3 - 1, ALPHA + i2 - 1, loop+1 , settings)==1)
					{
						settings->shringcount=settings->shringcount-1;
						settings->shringset[i3 - 1]=0;
					}
					chooseBC[i3-1]=0;
				}
				else
				{
					//printf("i3==-1   \n");
					break;
				}
				averagef=settings->SumF[loop]-(settings->bmu_low[loop]+settings->bmu_up[loop])/2.0*settings->BCu[loop];
				averagef=averagef/settings->BCu[loop];
					
			}
			free(chooseBC);
		}
		else
		{
			F2=F2;
		}
		if(optimal==TRUE)
			return FALSE;
		else
			return TRUE;
	}
}

BOOL smo_ordinal (smo_Settings * settings)
{
	int * label;
	double fx,Ex,* Maxdis,threshold=0,alldis;
	unsigned int guass,disnum=0;
	Data_Node * pair;
	int max=100,MAX=1000,MAXMAX;
	BOOL examineAll= TRUE ,Shrinkage= FALSE,WORK=TRUE ;
	long unsigned int numChanged = 0,errornum,absoluteerrornum ;
	Alphas * alpha = NULL ;   
	long unsigned int loop = 0 ,loop1=0;
	unsigned int j = 0,i1=0 ,i=0,j2,j3,trainnum,testnum,k,k2;
	double temp=0,F2=0,averagey,averagef;
	int s=0;
	Alphas *aup,*alow,*a0;
	label=(int *) calloc(settings->pairs->classes,sizeof(int)) ;
	if (NULL == settings)
		return FALSE ;
	settings->BCi=0;
	SMO_WORKING = TRUE ;
	if(settings->first==TRUE||settings->clean==TRUE)
		Clean_Alphas (ALPHA, settings) ;	
	Check_Alphas ( ALPHA, settings ) ;
	if(FALSE==preSMO(settings))
	{
		printf("preSMO failes");
		system("pause");
		return FALSE;
	}

	settings->startBC=FALSE;
	settings->startshringking=FALSE;
	settings->shringcount=min(1000,settings->pairs->count);
	settings->shringcounttemp=0;
	settings->shringset=(int *) calloc(settings->pairs->count,sizeof(int)) ;
	settings->mu = (double *) calloc((settings->pairs->classes-1),sizeof(double)) ;
	tstart() ; //timer on
	examineAll= TRUE ;
	WORK=TRUE ;
	MAX=50;
	MAXMAX=200;
	// main routine 



	while ( (numChanged > 0 || examineAll)   )
	{
		if ( examineAll )
		{
			// loop over all pairs		
			numChanged = 0 ;
			if(WORK==TRUE&&settings->pairs->workingcount==settings->pairs->count&&settings->startBC==TRUE)
			{
				for(loop=settings->pairs->truecount+1;loop<=settings->pairs->workingcount;loop++)
					numChanged += ordinal_examine_example( ALPHA + loop - 1, settings ) ; 
			}
			for ( loop = 1; loop <=settings->pairs->workingcount; loop ++ )
			{
				//if(WORK==FALSE)
				//{
					if(loop>settings->pairs->truecount)
						continue;
				//}
				if(settings->shringset[loop-1]==0||settings->first==TRUE)
					numChanged += ordinal_examine_example( ALPHA + loop - 1, settings ) ; 
				else
				{
					printf("");
				}
			}
			if(numChanged==0&&Shrinkage==TRUE)
			{
				Shrinkage=FALSE;
				examineAll=FALSE;
				for(i=0;i<settings->pairs->truecount;i++)
					settings->shringset[i]=0;
				settings->shringcount=0;
			}
			if(numChanged<=(settings->pairs->classes-1))
			{
				MAX--;
				MAXMAX--;
				if(MAX==-1)
				{
					WORK=FALSE;
					printf("max");
				}
				if(MAXMAX==-1)
				{
					WORK=FALSE;
					printf("MAX");
				}
					
			}
			else
				MAX=50;

		}
		else
		{
			// check the worse pair
			if(numChanged<min(1000,settings->pairs->count))
				settings->startshringking=TRUE;
			j = active_cross_threshold (settings) ;
			max=100;
			//if(settings->shringcount<=0)
			while ( j>0 && numChanged>0 )
			{
				numChanged=0;
				numChanged += ordinal_cross_takestep (ALPHA + settings->ij_up[settings->imu_up[j-1]-1] - 1,settings->imu_up[j-1],
									ALPHA + settings->ij_low[settings->imu_low[j-1]-1] - 1,settings->imu_low[j-1], settings);
				settings->shringcount=settings->shringcount-1;
				j = active_cross_threshold (settings) ;
			}
			numChanged = 0 ;
			settings->startBC=TRUE;
			if(settings->shringcount<=0&&settings->first==FALSE&&settings->startshringking==TRUE)
			{
				settings->shringcounttemp=0;
				Shrinkage=TRUE;
				settings->shringcount=min(1000,settings->pairs->count);
				for(i=0;i<settings->pairs->truecount;i++)
				{
					alpha=ALPHA+i;
					settings->shringset[i]=1;
					if(!Is_Io(alpha,settings))
						alpha->f_cache=Calculate_Ordinal_Fi(i+1,settings);
					for(j=0;j<settings->pairs->classes-1;j++)
					{
						if(alpha->setname[j]==I_Fou)
						{
							if((alpha->f_cache-1)>=settings->bmu_up[j])
								settings->shringset[i]=0;
						}
						else if(alpha->setname[j]==I_One)
						{
							if((alpha->f_cache-1)<=settings->bmu_low[j])
								settings->shringset[i]=0;
						}
						else if(alpha->setname[j]==I_Thr)
						{
							if((alpha->f_cache+1)<=settings->bmu_low[j])
								settings->shringset[i]=0;
						}
						else if(alpha->setname[j]==I_Two)
						{
							if((alpha->f_cache+1)>=settings->bmu_up[j])
								settings->shringset[i]=0;
						}
						else
						{
							settings->shringset[i]=0;
						}

					}

				}
			}
			//else
			//	printf("save time  \n");
		} // end of if-else

		if ( TRUE == examineAll )
		{
			examineAll = FALSE ;
		}
		else if ( 0 == numChanged )
		{
			examineAll = TRUE ;
		}

	} // end of while

	tend() ;
	settings->smo_timing = tval() ;
	DURATION += settings->smo_timing ;
	printf("smo spend : %f  \n",settings->smo_timing);
	for (loop=1;loop<settings->pairs->classes;loop++)
	{
		if(settings->bmu_low[loop-1]- settings->bmu_up[loop-1]>0.001)
		{
			printf("Warning: bmu_low > bmu_up  \n") ;
			system("pause");
		}
		settings->biasj[loop-1] = (settings->bmu_low[loop-1] + settings->bmu_up[loop-1])/2.0 ;
		if (loop > 1)
		{
			if (settings->biasj[loop-1]+TOL<settings->biasj[loop-2])
			{
				printf("Warning: thresholds %lu : %f < thresholds %lu : %f.\n",loop, settings->biasj[loop-1], loop-1, settings->biasj[loop-2]) ;
				system("pause");
			}
		}
	}

	F2=0;
	if(settings->pairs->workingcount==settings->pairs->count)
	{
		for (loop = 0 ; loop < settings->pairs->classes-1 ; loop ++)
		{
			averagey=0;
			averagef=0;
			//for(loop1=0;loop1<settings->traindata->count;loop1++)
			//{
			//	if((ALPHA+loop1)->pair->target>loop+1)
			//		averagey+=1;
			//	else
			//		averagey+=-1;
			//}

			averagey=settings->sumy[loop]/settings->BCn[loop];
			
			//averagef=settings->SumF-(settings->bj_low[loop]+settings->bj_up[loop])/2*settings->testdata->count;
			averagef=0;
			//for(loop1=settings->traindata->count;loop1<(settings->traindata->count+settings->testdata->count);loop1++)
			//{
			//	averagef+=((Calculate_Ordinal_Fi(loop1+1,settings)-(settings->bj_low[loop]+settings->bj_up[loop])/2))*settings->GBC[loop1][loop];
			//}

			//averagef=averagef/settings->BCu[loop];
			averagef=settings->SumF[loop]-(settings->bmu_low[loop]+settings->bmu_up[loop])/2.0*settings->BCu[loop];
			averagef=averagef/settings->BCu[loop];
			if(fabs(averagey-averagef)>0.001)
			{
				printf("BC : %lf   \n",fabs(averagey-averagef));
			}
		}
	}
 	errornum=0;
	absoluteerrornum=0;
	if(settings->pairs->workingcount==settings->pairs->count)
	{
		for(loop=0;loop<settings->pairs->truecount;loop++)
		{
			alpha=ALPHA+loop;
			for(loop1=0;loop1<settings->pairs->classes-1;loop1++)
			{
				Ex=alpha->f_cache-settings->biasj[loop1]-alpha->y[loop1];
	//			 if abs(aik)<exp&&(yik*Ex)>-1*toler
	//%                  noagainstnum=noagainstnum+1;
	//%              elseif aik<(C-exp)&&(yik*Ex)<toler&&(yik*Ex)>-1*toler
	//%                  noagainstnum=noagainstnum+1;
	//%              elseif aik<(C+exp)&&(yik*Ex)<toler
	//%                  noagainstnum=noagainstnum+1;
				if( (alpha->setname[loop1]==I_One || alpha->setname[loop1]==I_Two)&& (alpha->y[loop1]*Ex>-TOL)  )
					errornum+=1;
				else if((alpha->setname[loop1]==Io_b || alpha->setname[loop1]==Io_a)&& (alpha->y[loop1]*Ex<TOL)&&(alpha->y[loop1]*Ex>-TOL))
					errornum+=1;
				else if((alpha->setname[loop1]==I_Fou || alpha->setname[loop1]==I_Thr)&&(alpha->y[loop1]*Ex<TOL))
					errornum+=1;
				else
					printf("");
			}
		}
		errornum=(settings->pairs->truecount)*(settings->pairs->classes-1)-errornum;
		if(errornum>0)
		{
			printf("%lu  \n",errornum);
		}
	}
	if(settings->pairs->workingcount<settings->pairs->count)
	{
		settings->pairs->workingcount=settings->pairs->count;
		for(loop=settings->traindata->count;loop<settings->pairs->truecount;loop++)
			(ALPHA+loop)->f_cache=Calculate_Ordinal_Fi(loop+1,settings);

	}
	for(loop=0;loop<settings->pairs->classes;loop++)
	{
		label[loop]=0;
	}
	threshold=settings->threshold;
	Maxdis=(double *) calloc(settings->pairs->classes-1,sizeof(double)) ;
	for(loop=1;loop<=settings->traindata->count;loop++)
	{
		alpha=(ALPHA+loop-1);
		fx=alpha->f_cache;
		
		for(loop1=0;loop1<settings->traindata->classes-1;loop1++)
		{
			if(fabs(fx-settings->biasj[loop1])>Maxdis[loop1])
				Maxdis[loop1]=fabs(fx-settings->biasj[loop1]);
		}
	}


	//for(loop1=0;loop1<settings->traindata->classes-1;loop1++)
	//{
	//	for(loop=1;loop<=settings->traindata->count;loop++)
	//	{
	//		alpha=(ALPHA+loop-1);
	//		fx=alpha->f_cache;
	//		Maxdis[loop1]+=fabs(fx-settings->biasj[loop1]);
	//	}
	//	Maxdis[loop1]=Maxdis[loop1]/settings->traindata->count;
	//}


	if(settings->first==TRUE)
	{
		for(loop1=0;loop1<settings->pairs->classes-1;loop1++)
		{
			settings->BCn[loop1]=0;
			settings->BCu[loop1]=0;
		}
	}

	
	pair=settings->traindata->front;
	errornum=0;
	absoluteerrornum=0;
	for(loop=1;loop<=settings->traindata->count;loop++)
	{
		guass=1;
		alpha=(ALPHA+loop-1);
		fx=alpha->f_cache;
		
		for(loop1=0;loop1<settings->traindata->classes-1;loop1++)
		{
			if(settings->first==TRUE)
			{
				if(fabs(fx-settings->biasj[loop1])>threshold*Maxdis[loop1])
					settings->GBC[loop-1][loop1]=0;
				else
				{
					settings->GBC[loop-1][loop1]=1;
					settings->BCn[loop1]++;
					disnum++;
				}
			}
				
			//settings->GBC[loop-1][loop1]=exp(-0.1*pow(fx-settings->biasj[loop1],2));
			if(fx>settings->biasj[loop1])
				guass=loop1+2;
		}
		//printf("��%u��  %u :  %u  \n",loop,guass,pair->target);
		label[guass-1]++;
		if(pair->target!=guass)
			errornum+=1;
		pair=pair->next;
	}
	loop=0;
	printf("%lu /  %lu  \n",errornum,settings->traindata->count);
	for(loop=0;loop<settings->pairs->classes;loop++)
	{		
		//printf("%d :  %d  \n",loop+1,label[loop]);

		label[loop]=0;
	}
	
	pair=settings->testdata->front;
	errornum=0;
	absoluteerrornum=0;
	
	for(loop=1;loop<=settings->testdata->count;loop++)
	{
		guass=1;
		alpha=(ALPHA+loop+settings->traindata->count-1);
		fx=alpha->f_cache;
		for(loop1=0;loop1<settings->traindata->classes-1;loop1++)
		{
			if(settings->first==TRUE)
			{
				if(fabs(fx-settings->biasj[loop1])>threshold*Maxdis[loop1])
					settings->GBC[loop+settings->traindata->count-1][loop1]=0;
				else
				{
					settings->GBC[loop+settings->traindata->count-1][loop1]=1;
					settings->BCu[loop1]++;
					disnum++;
				}
			}

			//settings->GBC[loop+settings->traindata->count-1][loop1]=exp(-0.1*pow(fx-settings->biasj[loop1],2));
			if(fx>settings->biasj[loop1])
				guass=loop1+2;
		}
		//printf("��%u��  %u :  %u  \n",loop,guass,pair->target);
		label[guass-1]++;
		if(pair->target!=guass)
		{
			errornum+=1;
			absoluteerrornum+=abs(pair->target-guass);
		}
			
		pair=pair->next;
	}
	printf("%lu /  %lu =  %lf \n",errornum,settings->testdata->count,1.0*errornum/settings->testdata->count);
	printf("%lu /  %lu =  %lf \n",absoluteerrornum,settings->testdata->count,1.0*absoluteerrornum/settings->testdata->count);
	loop=0;
	for(loop=0;loop<settings->pairs->classes;loop++)
	{
		printf("%d :  %d  \n",loop+1,label[loop]);
		label[loop]=0;
	}
	
	//printf("%lf  \n",Maxdis);
	//printf("%d   \n",disnum);
	//�˺���

	trainnum=settings->traindata->count;
	testnum=settings->testdata->count;
	if(settings->first==TRUE)
	{
		for(loop=settings->pairs->truecount;loop<settings->pairs->count;loop++)
		{
			k=loop-settings->pairs->truecount;
			alpha=ALPHA+loop;
			for(j=0;j<loop+1;j++)
				alpha->kernel[j]=0;
			for(j=0;j<loop+1;j++)
			{
				if(j<settings->pairs->truecount)
				{
					for(j2=trainnum;j2<trainnum+testnum;j2++)
					{
						alpha->kernel[j]+=settings->GBC[j2][k]*Calc_Kernel(ALPHA+j,ALPHA+j2,settings);
					}
					alpha->kernel[j]/=settings->BCu[k];
				}
				else
				{
					k2=j-settings->pairs->truecount;
					for(j2=trainnum;j2<trainnum+testnum;j2++)
						for(j3=trainnum;j3<trainnum+testnum;j3++)
							alpha->kernel[j]+=settings->GBC[j2][k]*settings->GBC[j3][k2]*Calc_Kernel(ALPHA+j2,ALPHA+j3,settings);
					alpha->kernel[j]/=settings->BCu[k]*settings->BCu[k2];
				}
			}

		}
	}
	j=1;
	temp=0;
	for(loop=settings->traindata->count;loop<(settings->traindata->count+2*settings->testdata->count);loop++)
	{
		alpha=ALPHA+loop;
		for(loop1=0;loop1<settings->pairs->classes-1;loop1++)
		{
			
			s=alpha->y[loop1];
			if(s*(alpha->f_cache-settings->biasj[loop1])<0)
				temp=alpha->vc;
			else
				temp=0;
			if(alpha->beta[loop1]!=temp)
			{
				j=0;
				alpha->beta[loop1]=temp;
			}

		}
	}
	if(settings->first==FALSE)
		settings->clean=FALSE;
	settings->first=FALSE;
	if(j==1)
		return FALSE ; 
	else
		return TRUE;
	
}

BOOL smo_routine (smo_Settings * settings)
{
	if (NULL == settings)
		return FALSE ;

	if (ORDINAL == settings->pairs->datatype)
		return smo_ordinal (settings) ;
	else
	{
		printf("\nThe data type is not ORDINAL REGRESSION.\n") ;
		system("pause");
		exit(1) ;
	}
}

// end of smo_routine.c
BOOL preSMO(smo_Settings * settings)
{
	Alphas * alpha = NULL ;   
	long unsigned int loop = 0 ,loop1=0,loop2=0;
	settings->SumK=(double **) calloc(settings->pairs->classes-1,sizeof(double*)) ;
	for(loop=0;loop<settings->pairs->classes-1;loop++)
		settings->SumK[loop]=(double *) calloc(settings->pairs->count,sizeof(double)) ;
	for(loop=0;loop<settings->pairs->classes-1;loop++)
		for(loop1=0;loop1<settings->pairs->count;loop1++)
			for(loop2=settings->traindata->count;loop2<settings->traindata->count+settings->testdata->count;loop2++)
			{
				settings->SumK[loop][loop1]+=Calc_Kernel(ALPHA+loop1,ALPHA+loop2,settings)*settings->GBC[loop2][loop];
			}
	settings->SumF=(double *) calloc(settings->pairs->classes-1,sizeof(double)) ;
	for(loop=settings->traindata->count;loop<settings->traindata->count+settings->testdata->count;loop++)
	{
		alpha=ALPHA+loop;
		for(loop1=0;loop1<settings->pairs->classes-1;loop1++)
		{
			settings->SumF[loop1]+=alpha->f_cache*settings->GBC[loop][loop1];
		}
	}
	settings->sumy=(double *) calloc(settings->pairs->classes-1,sizeof(double)) ;
	for(loop=0;loop<settings->traindata->count;loop++)
	{
		alpha=ALPHA+loop;
		for(loop1=0;loop1<settings->pairs->classes-1;loop1++)
		{
			settings->sumy[loop1]+=alpha->y[loop1]*settings->GBC[loop][loop1];
		}
	}
	return TRUE;
}