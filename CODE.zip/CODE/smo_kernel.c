/*******************************************************************************\

	smo_kernel.c in Sequential Minimal Optimization ver2.0
		
	calculates the Kernel.

	Chu Wei Copyright(C) National Univeristy of Singapore
	Create on Jan. 16 2000 at Control Lab of Mechanical Engineering 
	Update on Aug. 23 2001 

\*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <sys/types.h> 
#include <sys/timeb.h>
#include "smo.h"

double Calculate_Kernel( float * pi, float * pj, smo_Settings * settings )
{
	long unsigned int dimen = 0 ;
	long unsigned int dimension = 0 ;
	double kernel = 0 ;	

	if ( NULL == pi || NULL == pj || NULL == settings )
		return kernel ;
	
	if (settings->pairs->dimen<1)
	{
		printf("Warning : dimension is less than 1.\n") ;
		return kernel ;
	}

	dimension = settings->pairs->dimen ;
	if ( POLYNOMIAL == KERNEL )	
	{
		if ( pi[dimen]!=0 && pj[dimen]!=0 )
				kernel = kernel + pi[dimen] * pj[dimen] ;
		if ((double) P > 1.0)
			kernel = pow( (kernel + 1.0), (double) P ) ;
	}
	else if ( GAUSSIAN == KERNEL )
	{
		for ( dimen = 0; dimen < dimension; dimen ++ )
		{
			if ( pi[dimen]!=pj[dimen] )
				kernel = kernel + KAPPA * ( pi[dimen] - pj[dimen] ) * ( pi[dimen] - pj[dimen] );	
		}
		kernel = exp ( -  kernel / 10.0) ; 
	}
	else 
	{
		if ( pi[dimen]!=0 && pj[dimen]!=0 )
				kernel = kernel + pi[dimen] * pj[dimen] ;
	}
	//if (pi==pj)
	//	return kernel + 0.001 ;
	//else
		return kernel ;	
}

double Calc_Kernel( struct _Alphas * ai, struct _Alphas * aj, smo_Settings * settings )
{
	unsigned int trainnum,testnum;
	double kernel = 0 ;
	float * pi ;
	float * pj ;
	int i, j ;
	trainnum=settings->traindata->count;
	testnum=settings->testdata->count;

	if ( NULL == ai || NULL == aj || NULL == settings )
		return kernel ;

	if (settings->pairs->dimen<1)
	{
		printf("Warning : dimension is less than 1.\n") ;
		return kernel ;
	}

	if (TRUE == settings->cacheall)
	{
		// retrieve kernel values
		i = ai - ALPHA ;
		j = aj - ALPHA ;
		//if(i==(settings->pairs->count-1))
		//	return ai->kernel[j*(settings->pairs->classes-1)+k];
		//if(j==(settings->pairs->count-1))
		//	return aj->kernel[i*(settings->pairs->classes-1)+k];
		if(i>(trainnum+testnum-1)&&i<(trainnum+2*testnum))
		{i=i-testnum;ai=ALPHA+i;}
		if(j>(trainnum+testnum-1)&&j<(trainnum+2*testnum))
		{j=j-testnum;aj=ALPHA+j;}
		if (i >= j)
			return ai->kernel[j] ;
		else if ( i < j )
			return aj->kernel[i] ;
		
	}

	pi = ai->pair->point ;
	pj = aj->pair->point ;

	return Calculate_Kernel(pi, pj, settings) ;
}
// the end of smo_kernel.c 

//BOOL InitSumK(smo_Settings * settings)
//{
//	long unsigned  int i,j;
//	settings->SumK=(double *) calloc(settings->pairs->count,sizeof(double)) ;
//	if(settings->SumK==NULL)
//	{
//		printf("malloc settings->SumK failed");
//		system("pause");
//		return FALSE;
//	}
//	for(i=0;i<settings->pairs->count;i++)
//	{
//		for(j=settings->traindata->count;j<settings->traindata->count+settings->testdata->count;j++)
//		{
//			settings->SumK[i]+=Calc_Kernel(ALPHA+i,ALPHA+j,settings);
//		}
//	}
//	return TRUE;
//}