/*******************************************************************************\

	smoc_takestep.c in Sequential Minimal Optimization ver2.0
	
	implements the takestep function of SMO for Classification.
			
	Chu Wei Copyright(C) National Univeristy of Singapore
	Create on Jan. 16 2000 at Control Lab of Mechanical Engineering 
	Update on Aug. 24 2001 	

\*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include "smo.h"

BOOL ordinal_takestep ( Alphas * alpha1, Alphas * alpha2, unsigned int threshold, smo_Settings * settings )
{
	double  n1 = 0, n2 = 0, a1 = 0, a2 = 0,e1,e2,b1,b2;	//new and old alphas
	BOOL nset1, nset2, set1, set2 ; 
	double F1 = 0, F2 = 0 ;
	double s1 = 1, s2 = 1 ;
	double K11 = 0, K12 = 0, K22 = 0 ;
	double ueta = 0, gamma = 0, delphi = 0 ;
	double H = 0, L = 0 ;
	double ObjH = 0, ObjL = 0 ;
	Set_Name name1, name2 ;
	Alphas * alpha3 = NULL ;
	Cache_Node * cache = NULL ;
	int * index ; 
#ifdef _ORDINAL_DEBUG
	double temp = 0 ; 
	double temp1, temp2 ;
#endif 
	long unsigned int i1 = 0 ;
	long unsigned int i2 = 0 ; 
	unsigned int t1, t2 ;
	unsigned int loop,loop1 ;

	if ( NULL == alpha1 || NULL == alpha2 || NULL == settings )
	{
		printf( " Alpha list error. \r\n" ) ;
		return FALSE ;
	}
	if (threshold<=0)
	{
		printf( " Active threshold %u is zero.\n", threshold) ;
		return FALSE ;
	}

	if (threshold >= settings->pairs->classes)
	{
		printf( " Active threshold %u is greater than %u.\n", threshold, settings->pairs->classes-1) ;
		return FALSE ;
	}
    
	if((alpha2-ALPHA)>=(settings->pairs->truecount))
	{
		alpha3=alpha2;
		alpha2=alpha1;
		alpha1=alpha3;
	}

	i1 = alpha1-ALPHA+1 ;
	i2 = alpha2-ALPHA+1 ;

	if(settings->pairs->workingcount<settings->pairs->count)
	{
		if(i1>settings->pairs->workingcount||i2>settings->pairs->workingcount)
		  printf("");
	}
	if ( i1 == i2 ) 
		return FALSE ;

	t1 = alpha1->pair->target ;
	t2 = alpha2->pair->target ;

	name1 = alpha1->setname[threshold-1];
	name2 = alpha2->setname[threshold-1] ;

	set1 = Is_Io(alpha1,settings) ;
	set2 = Is_Io(alpha2,settings) ;

	e2=1;
	if((alpha1-ALPHA)>=(settings->pairs->truecount))
	{
		//e1=0;
		//for(loop=0;loop<settings->traindata->count;loop++)
		//{
		//	if((ALPHA+loop)->pair->target>threshold)
		//		e1+=1;
		//	else
		//		e1+=-1;
		//}
		e1=settings->sumy[threshold-1]/settings->BCn[threshold-1];
		//threshold=1;
	}
	else
		e1=1;

	b1=alpha1->beta[threshold-1];
	b2=alpha2->beta[threshold-1];

	a1 = n1 = alpha1->alpha[threshold-1] - b1 ;		//a
	a2 = n2 = alpha2->alpha[threshold-1] -b2;		//a*
	
	//if (t1<=(threshold)&&t2>=(threshold+1))
	//{
	//	s1 = +1 ;
	//	s2 = -1 ;
	//}
	//else if (t1>=(threshold+1)&&t2<=(threshold))
	//{
	//	s1 = -1 ;		
	//	s2 = +1 ;
	//}
	//else if (t1<=(threshold)&&t2<=(threshold))
	//{
	//	s1 = +1 ;		//a
	//	s2 = +1 ;
	//}
	//else if (t1>=(threshold+1)&&t2>=(threshold+1))
	//{
	//	s1 = -1 ;
	//	s2 = -1 ;
	//}
	//else
	//{
	//	printf("\nWarning : fail to specify the case.\n") ;
	//	system("pause");
	//	exit(1) ;
	//}

	s1=-alpha1->y[threshold-1];
	s2=-alpha2->y[threshold-1];

	F1 = alpha1->f_cache ;	
	F2 = alpha2->f_cache ;		
	// must update Io & I_LOW & I_UP every accepted step

	K11 = Calc_Kernel( alpha1, alpha1, settings) ; 
	K12 =Calc_Kernel( alpha1, alpha2, settings ) ; 
	K22 =Calc_Kernel( alpha2, alpha2, settings ) ; 

	ueta = K11 + K22 - K12 - K12 ;
	
	if ( 0 >= ueta )
	{ 
		// calculate objective function at H or L, choose the smaller one
		//printf("\n Warning: Negative Definite Matrix.\n") ;
		ObjH=0 ;
		ObjL=0 ;
		return FALSE ;
	}
	else // normal condition
	{
		//boundary
		if(s1==s2)
			{
				H=min(alpha2->vc-b2,a2+a1+b1);
				L=max(-b2,a2+a1-alpha1->vc+b1);
			}
			else
			{
				H=min(alpha2->vc-b2,a2-a1+alpha1->vc-b1);
				L=max(-b2,a2-a1-b1);
			}
		delphi = - F1 + F2 - s1*e1 + s2*e2 ;		

		n2 = a2 + s2*delphi/ueta ;
		if((alpha1-ALPHA)>=(settings->pairs->truecount))
		{
			H=alpha2->vc-b2;
			L=-b2;
		}
		if(H<=L)
			return FALSE;

		if(n2>H)
			n2=H;
		if(n2<L)
			n2=L;
		n1=(-s1)*a1+(-s2)*a2-(-s2)*n2;
		n1=n1*(-s1);
	} //end of if ueta 

	// update Alpha List if necessary, then update Io_Cache, and vote B_LOW & B_UP
	if ( fabs(n2 - a2) > 0 )
	{
		// store alphas in Alpha List
		a1+=b1;
		n1+=b1;
		a2+=b2;
		n2+=b2;


		if((alpha1-ALPHA)==(settings->pairs->count-1) || (alpha2-ALPHA)==(settings->pairs->count-1))
			printf("");
		alpha1->alpha[threshold-1] = n1 ;
		alpha2->alpha[threshold-1] = n2 ;

		// update Set & Cache_List  

		alpha1->setname[threshold-1] = Get_Ordinal_Label(alpha1,threshold,settings) ;
		alpha2->setname[threshold-1] = Get_Ordinal_Label(alpha2,threshold,settings) ;

		nset1 = Is_Io(alpha1,settings) ;
		nset2 = Is_Io(alpha2,settings) ;

		if ( nset1 != set1 )
		{			
			if ( TRUE == nset1 && FALSE == set1 )	
				Add_Cache_Node( &Io_CACHE, alpha1 ) ; // insert into Io 
			if ( FALSE == nset1 && TRUE == set1 )
				Del_Cache_Node( &Io_CACHE, alpha1 ) ;
		}		
		if ( nset2 != set2 )
		{						
			if ( TRUE == nset2 && FALSE == set2 )		
				Add_Cache_Node( &Io_CACHE, alpha2 ) ; // insert into Io 						
			if ( FALSE == nset2 && TRUE == set2 )
				Del_Cache_Node( &Io_CACHE, alpha2 ) ;
		}

		
		 //Check_Alphas ( ALPHA, settings ) ;

		index = (int *)calloc(settings->pairs->count,sizeof(int)) ;
		if (NULL == index)
		{
			printf("\n FATAL ERROR : fail to malloc index.\n") ;
			system("pause");
			exit(1) ;
		}
		 //����bup  blow  ��ֵ
		for (loop = 1 ; loop < settings->pairs->classes ; loop ++)
		{
			alpha3 = ALPHA + settings->ij_up[loop-1] - 1 ;
			if (alpha3!=alpha1&&alpha3!=alpha2&&FALSE==Is_Io(alpha3,settings)) 
			{
				settings->bj_up[loop-1] += 
					- s1*(n1 - a1)*Calc_Kernel( alpha1, alpha3, settings ) 
					- s2*(n2 - a2)*Calc_Kernel( alpha2, alpha3, settings ) ;
				if (0==index[alpha3-ALPHA])
				{
					alpha3->f_cache +=  
						- s1*(n1 - a1)*Calc_Kernel( alpha1, alpha3, settings) 
						- s2*(n2 - a2)*Calc_Kernel( alpha2, alpha3, settings ) ;
					index[alpha3-ALPHA] = 1 ;
				}
			}
			else
			{
				settings->bj_up[loop-1] = INT_MAX ;
				settings->ij_up[loop-1] = 0 ;
			}
			alpha3 = ALPHA + settings->ij_low[loop-1] - 1 ;
			if (alpha3!=alpha1&&alpha2!=alpha3&&FALSE==Is_Io(alpha3,settings)) 
			{	
				settings->bj_low[loop-1] += 
					- s1*(n1 - a1)*Calc_Kernel( alpha1, alpha3, settings) 
					- s2*(n2 - a2)*Calc_Kernel( alpha2, alpha3, settings ) ;
				if (0==index[alpha3-ALPHA])
				{
					alpha3->f_cache +=  
						- s1*(n1 - a1)*Calc_Kernel( alpha1, alpha3, settings ) 
						- s2*(n2 - a2)*Calc_Kernel( alpha2, alpha3, settings) ;
					index[alpha3-ALPHA] = 1 ;
				}
			}
			else
			{
				settings->bj_low[loop-1] = INT_MIN ;
				settings->ij_low[loop-1] = 0 ;
			}
		}
		//���� i1  i2 ��ֵ  ��ѡ��b
		if ( FALSE==Is_Io(alpha1,settings) )
		{
			if (0==index[alpha1-ALPHA])
			{
				alpha1->f_cache = alpha1->f_cache 				
					- s1*(n1 - a1)*K11 - s2*(n2 - a2)*K12 ;
				index[alpha1-ALPHA] = 1 ;
			}
			alpha3 = alpha1 ;
			for (loop = 0 ; loop < settings->pairs->classes-1 ; loop ++)
			{
				if (alpha3->pair->target > (loop+1) )
				{
					//lower
					if (alpha3->setname[loop]==Io_b || alpha3->setname[loop]==I_One)
					{
						if (alpha3->f_cache-1<settings->bj_up[loop])
						{
							settings->bj_up[loop] = alpha3->f_cache-1 ;
							settings->ij_up[loop] = alpha3 - ALPHA + 1 ;
						}
					}
					if (alpha3->setname[loop]==Io_b || alpha3->setname[loop]==I_Fou)
					{
						if (alpha3->f_cache-1>settings->bj_low[loop])
						{
							settings->bj_low[loop] = alpha3->f_cache-1 ;
							settings->ij_low[loop] = alpha3 - ALPHA + 1 ;
						}
					}
				}
				else
				{
					//upper
					if (alpha3->setname[loop]==Io_a || alpha3->setname[loop]==I_Thr)
					{
						if (alpha3->f_cache+1<settings->bj_up[loop])
						{
							settings->bj_up[loop] = alpha3->f_cache+1 ;
							settings->ij_up[loop] = alpha3 - ALPHA + 1 ;
						}
					}
					if (alpha3->setname[loop]==Io_a || alpha3->setname[loop]==I_Two)
					{
						if (alpha3->f_cache+1>settings->bj_low[loop])
						{
							settings->bj_low[loop] = alpha3->f_cache+1 ;
							settings->ij_low[loop] = alpha3 - ALPHA + 1 ;
						}
					}
				}
			}		
		}
		if ( FALSE==Is_Io(alpha2,settings) )
		{
			if (0==index[alpha2-ALPHA])
			{
				alpha2->f_cache = alpha2->f_cache 			
					- s1*(n1 - a1)*K12 - s2*(n2 - a2)*K22 ;
				index[alpha2-ALPHA] = 1 ;
			}			
			alpha3 = alpha2 ;
			for (loop = 0 ; loop < settings->pairs->classes-1 ; loop ++)
			{
				if (alpha3->pair->target > (loop+1) )
				{
					//lower
					if (alpha3->setname[loop]==Io_b || alpha3->setname[loop]==I_One)
					{
						if (alpha3->f_cache-1<settings->bj_up[loop])
						{
							settings->bj_up[loop] = alpha3->f_cache-1 ;
							settings->ij_up[loop] = alpha3 - ALPHA + 1 ;
						}
					}
					if (alpha3->setname[loop]==Io_b || alpha3->setname[loop]==I_Fou)
					{
						if (alpha3->f_cache-1>settings->bj_low[loop])
						{
							settings->bj_low[loop] = alpha3->f_cache-1 ;
							settings->ij_low[loop] = alpha3 - ALPHA + 1 ;
						}
					}
				}
				else
				{
					//upper
					if (alpha3->setname[loop]==Io_a || alpha3->setname[loop]==I_Thr)
					{
						if (alpha3->f_cache+1<settings->bj_up[loop])
						{
							settings->bj_up[loop] = alpha3->f_cache+1 ;
							settings->ij_up[loop] = alpha3 - ALPHA + 1 ;
						}
					}
					if (alpha3->setname[loop]==Io_a || alpha3->setname[loop]==I_Two)
					{
						if (alpha3->f_cache+1>settings->bj_low[loop])
						{
							settings->bj_low[loop] = alpha3->f_cache+1 ;
							settings->ij_low[loop] = alpha3 - ALPHA + 1 ;
						}
					}
				}
			}		
		}
		//����֧��������ֵ ��ѡ��b
		cache = Io_CACHE.front ;
		while ( NULL != cache ) 
		{
			alpha3 = cache->alpha ;
			if (0==index[alpha3-ALPHA])
			{
				alpha3->f_cache = alpha3->f_cache 
					- s1*(n1 - a1)*Calc_Kernel( alpha1, alpha3, settings) 
					- s2*(n2 - a2)*Calc_Kernel( alpha2, alpha3, settings) ;
				//if(fabs(alpha3->f_cache-Calculate_Ordinal_Fi(alpha3-ALPHA+1,settings))>0.001)
				//{
				//	alpha3->f_cache=Calculate_Ordinal_Fi(alpha3-ALPHA+1,settings);
				//}
				index[alpha3-ALPHA] = 1 ;
			}
			//temp = Calculate_Ordinal_Fi(alpha3-ALPHA+1,settings) ;

			for (loop = 0 ; loop < settings->pairs->classes-1 ; loop ++)
			{
				if (cache->alpha->pair->target > (loop+1) )
				{
					//lower
					if (cache->alpha->setname[loop]==Io_b || cache->alpha->setname[loop]==I_One)
					{
						if (cache->alpha->f_cache-1<settings->bj_up[loop])
						{
							settings->bj_up[loop] = cache->alpha->f_cache-1 ;
							settings->ij_up[loop] = cache->alpha - ALPHA + 1 ;
						}
					}
					if (cache->alpha->setname[loop]==Io_b || cache->alpha->setname[loop]==I_Fou)
					{
						if (cache->alpha->f_cache-1>settings->bj_low[loop])
						{
							settings->bj_low[loop] = cache->alpha->f_cache-1 ;
							settings->ij_low[loop] = cache->alpha - ALPHA + 1 ;
						}
					}
				}
				else
				{
					//upper
					if (cache->alpha->setname[loop]==Io_a || cache->alpha->setname[loop]==I_Thr)
					{
						if (cache->alpha->f_cache+1<settings->bj_up[loop])
						{
							settings->bj_up[loop] = cache->alpha->f_cache+1 ;
							settings->ij_up[loop] = cache->alpha - ALPHA + 1 ;
						}
					}
					if (cache->alpha->setname[loop]==Io_a || cache->alpha->setname[loop]==I_Two)
					{
						if (cache->alpha->f_cache+1>settings->bj_low[loop])
						{
							settings->bj_low[loop] = cache->alpha->f_cache+1 ;
							settings->ij_low[loop] = cache->alpha - ALPHA + 1 ;
						}
					}
				}
			}
			cache = cache->next ;
		}
		 //end of if-else to update B_LOW & B_UP
		
		
		for (loop = 0 ; loop < settings->pairs->classes-1 ; loop ++)
		{
			settings->SumF[loop]=settings->SumF[loop]
					-s1*(n1 - a1)*settings->SumK[loop][i1-1]
					-s2*(n2 - a2)*settings->SumK[loop][i2-1];
		}
		for (loop = 0 ; loop < settings->pairs->classes-1 ; loop ++)
		{
			alpha3=(ALPHA+settings->pairs->truecount+loop);
			if (0==index[alpha3-ALPHA])
			{
				alpha3->f_cache +=  
					- s1*(n1 - a1)*Calc_Kernel( alpha1, alpha3, settings) 
					- s2*(n2 - a2)*Calc_Kernel( alpha2, alpha3, settings ) ;
				index[alpha3-ALPHA] = 1 ;
			}
			//if(fabs(alpha3->f_cache-Calculate_Ordinal_Fi(alpha3-ALPHA+1,settings))>0.001)
			//{
			//	alpha3->f_cache=Calculate_Ordinal_Fi(settings->pairs->truecount+loop+1,settings);
			//}
		}
		free(index) ;
		//for(loop=0;loop<settings->pairs->classes-1;loop++)
		//{
		//	if(settings->ij_low[loop]==0 )
		//	{
		//		for(loop1=loop+1;loop1<settings->pairs->classes-1;loop1++)
		//		{
		//			if(settings->ij_low[loop1]!=0 )
		//			{
		//				settings->ij_low[loop]=settings->ij_low[loop1];
		//				settings->bj_low[loop]=settings->bj_low[loop1];
		//				break;
		//			}
		//		}
		//		if(settings->ij_low[loop]==0 )
		//		{
		//			for(loop1=loop-1;loop1>=0;loop1--)
		//			{
		//				if(settings->ij_low[loop1]!=0 )
		//				{
		//					settings->ij_low[loop]=settings->ij_low[loop1];
		//					settings->bj_low[loop]=settings->bj_low[loop1];
		//					break;
		//				}
		//			}
		//		}

		//	}
		//	if(settings->ij_up[loop]==0 )
		//	{
		//		
		//		for(loop1=loop-1;loop1>=0;loop1--)
		//		{
		//			if(settings->ij_up[loop1]!=0 )
		//			{
		//				settings->ij_up[loop]=settings->ij_up[loop1];
		//				settings->bj_up[loop]=settings->bj_up[loop1];
		//				break;
		//			}
		//		}
		//		if(settings->ij_up[loop]==0 )
		//		{
		//			for(loop1=loop+1;loop1<settings->pairs->classes-1;loop1++)
		//			{
		//				if(settings->ij_up[loop1]!=0 )
		//				{
		//					settings->ij_up[loop]=settings->ij_up[loop1];
		//					settings->bj_up[loop]=settings->bj_up[loop1];
		//					break;
		//				}
		//			}
		//		}
		//	}
		//}
		for(loop=0;loop<settings->pairs->classes-1;loop++)
		{
			if(settings->ij_low[loop]==0 )
			{
				settings->ij_low[loop]=settings->ij_up[loop];
				settings->bj_low[loop]=settings->bj_up[loop];
			}
			if(settings->ij_up[loop]==0 )
			{
				settings->ij_up[loop]=settings->ij_low[loop];
				settings->bj_up[loop]=settings->bj_low[loop];
			}
		}
		for (loop = 1 ; loop < settings->pairs->classes ; loop ++)
		{
			if (0==settings->ij_up[loop-1]||0==settings->ij_low[loop-1])
			{
				 Check_Alphas ( ALPHA, settings ) ;
				 break;
			}
				
		}

		// update mu_bias
		for (loop = 1; loop < settings->pairs->classes; loop ++)
		{
			settings->bmu_low[loop-1]=settings->bj_low[loop-1] ;
			settings->imu_low[loop-1]=loop ;
			if (loop>1)
			{	
				// b_low^j=max{b_low^j-1,b_low^j}
				if (settings->bmu_low[loop-2]>settings->bmu_low[loop-1])
				{
					settings->bmu_low[loop-1]=settings->bmu_low[loop-2] ;
					settings->imu_low[loop-1]=settings->imu_low[loop-2] ;
				}
			}
		}
		for (loop = settings->pairs->classes-1; loop > 0; loop --)
		{
			settings->bmu_up[loop-1]=settings->bj_up[loop-1] ;
			settings->imu_up[loop-1]=loop ;
			if (loop<settings->pairs->classes-1)
			{
				// b_up^j=min{b_up^j,b_up^j+1}
				if (settings->bmu_up[loop-1]>settings->bmu_up[loop])
				{
					settings->bmu_up[loop-1]=settings->bmu_up[loop] ;
					settings->imu_up[loop-1]=settings->imu_up[loop] ;
				}			
			}
		}
		for (loop = 2; loop < settings->pairs->classes; loop ++)
		{
			if (settings->mu[loop-1]>EPS*EPS) 
			{
				if (settings->bmu_up[loop-1]>settings->bmu_up[loop-2])
				{
					settings->bmu_up[loop-1]=settings->bmu_up[loop-2] ;
					settings->imu_up[loop-1]=settings->imu_up[loop-2] ;
				}
				if (settings->bmu_low[loop-2]<settings->bmu_low[loop-1])
				{
					settings->bmu_low[loop-2]=settings->bmu_low[loop-1] ;
					settings->imu_low[loop-2]=settings->imu_low[loop-1] ;
				}
			}
		}
		
		return TRUE ;
	} // end of update 
	else
	{
		return FALSE ;
	}
}


BOOL ordinal_cross_takestep ( Alphas * Bup, unsigned int threshold1, Alphas * Blow, unsigned int threshold2, smo_Settings * settings )
{
	double b1,b2;
	unsigned int threshold0=0;
	Set_Name name1,name2;
	BOOL nset1, nset2, set1, set2 ; 
	double a1 = 0, a1a = 0, a2 = 0, a2a = 0 ;	//old alpha
	double n1 = 0, n1a = 0, n2 = 0, n2a = 0 ;	//new alpha
	double F1 = 0, F2 = 0 ;
	BOOL case1 = FALSE, case2 = FALSE, case3 = FALSE, 
		case4 = FALSE ;  
	double K11 = 0, K12 = 0, K22 = 0 ;
	double ueta = 0, gamma = 0, delphi = 0 ,gammaH,gammaL;
	double H = 0, L = 0 ;
	double ObjH = 0, ObjL = 0 ;
	Set_Name name1_up, name1_dw, name2_up, name2_dw ;
	Alphas * alpha1 = NULL ;
	Alphas * alpha2 = NULL ;
	Alphas * alpha3 = NULL ;
	Cache_Node * cache = NULL ;

	long unsigned int i1 = 0 ;
	long unsigned int i2 = 0 ; 

	unsigned int t1, t2 ;
	int * index ;
	unsigned int loop ,loop1;
	int s1=0, s2=0, mu, mu1=0, mu2=0 ;
	double deltamu = -1 ;


	if ( NULL == Bup || NULL == Blow || NULL == settings )
	{
		printf( " Alpha list error. \r\n" ) ;
		return FALSE ;
	}

	if (threshold1 > settings->pairs->classes-1 || threshold1 < 1 || threshold2 > settings->pairs->classes-1 || threshold2 < 1)
	{
		printf( " Active threshold is greater than %u.\n", settings->pairs->classes-1) ;
		return FALSE ;
	}
   
	//printf("get in cross update.\n") ;

	if ( Bup == Blow )
	{
		//return ordinal_cross_identical (Bup, Blow, b1, settings) ;
		return FALSE;
	}

	//b1 = settings->imu_up[threshold-1] ;
	//b2 = settings->imu_low[threshold-1] ;

	if (threshold1==threshold2)
	{
		//printf("go to standard update.\n") ;
		return ordinal_takestep(Bup, Blow, threshold1, settings) ;
	}
	alpha1 = Bup ;
	alpha2 = Blow ;
	if(threshold1<threshold2)
	{
		alpha1 = Blow ;
		alpha2 = Bup ;
		threshold0=threshold1;
		threshold1=threshold2;
		threshold2=threshold0;
	}


	t1 = alpha1->pair->target ;
	t2 = alpha2->pair->target ;

	mu1=threshold1;
	mu2=threshold2;

	
	i1 = alpha1-ALPHA+1 ;
	i2 = alpha2-ALPHA+1 ;


	name1 = alpha1->setname[threshold1-1];
	name2 = alpha2->setname[threshold2-1] ;

	set1 = Is_Io(alpha1,settings) ;
	set2 = Is_Io(alpha2,settings) ;
	
	b1=alpha1->beta[threshold1-1];
	b2=alpha2->beta[threshold2-1];

	a1 = n1 = alpha1->alpha[threshold1-1] - b1 ;		//a
	a2 = n2 = alpha2->alpha[threshold2-1] -b2;		//a*

	F1 = alpha1->f_cache ;	
	F2 = alpha2->f_cache ;		// must update Io & I_LOW & I_UP every accepted step

	K11 = Calc_Kernel( alpha1, alpha1, settings ) ; 
	K12 = Calc_Kernel( alpha1, alpha2, settings ) ;
	K22 = Calc_Kernel( alpha2, alpha2, settings ) ; 

	ueta = K11 + K22 - K12 - K12 ;


	s1=-alpha1->y[threshold1-1];
	s2=-alpha2->y[threshold2-1];

	if ( 0 >= ueta )
	{
		//printf(" Negative Definite Matrix cross.\n") ;
		// calculate objective function at H or L, choose the smaller one
		ObjH=0 ;
		ObjL=0 ;
		return FALSE ;
	}
	else // normal condition
	{
		if(s1==s2)
		{
			H=min(alpha2->vc-b2,a2+a1+b1);
			L=max(-b2,a2+a1-alpha1->vc+b1);
		}
		else
		{
			H=min(alpha2->vc-b2,a2-a1+alpha1->vc-b1);
			L=max(-b2,a2-a1-b1);
		}
		if(H<=L)
			return FALSE;
		delphi = - F1 + F2 - s1 + s2 ;
		gamma=s2*delphi/ueta ;
		gammaH=H-a2;
		gammaL=L-a2;
		if(gamma>0&&s2<0)
		{
			for(mu=mu2;mu<mu1;mu++)
				gammaH=min(gammaH,settings->mu[mu]);
		}
		if(gamma<0&&s2>0)
		{
			for(mu=mu2;mu<mu1;mu++)
				gammaL=max(gammaL,-settings->mu[mu]);
		}
		gamma=min(gamma,gammaH);
		gamma=max(gamma,gammaL);
		n2=a2+gamma;
		n1=(-s1)*a1+(-s2)*a2-(-s2)*n2;
		n1=n1*(-s1);

	} //end of if ueta 		

	// update Alpha List if necessary, then update Io_Cache, and vote B_LOW & B_UP
	if ( fabs(n2 - a2) > 0 )
	{
		// store alphas in Alpha List
		a1+=b1;
		n1+=b1;
		a2+=b2;
		n2+=b2;
		if(n1<-EPS*EPS||n2<-EPS*EPS)
			printf("alpha<0 \n");
		for(mu=mu2;mu<mu1;mu++)
		{
			settings->mu[mu]-=gamma*s2*(-1);
			if(settings->mu[mu]<-EPS*EPS)
				printf("mu \n");
		}
			


		if((alpha1-ALPHA)==(settings->pairs->count-1) || (alpha2-ALPHA)==(settings->pairs->count-1))
			printf("");
		alpha1->alpha[threshold1-1] = n1 ;
		alpha2->alpha[threshold2-1] = n2 ;

		// update Set & Cache_List  

		alpha1->setname[threshold1-1] = Get_Ordinal_Label(alpha1,threshold1,settings) ;
		alpha2->setname[threshold2-1] = Get_Ordinal_Label(alpha2,threshold2,settings) ;

		nset1 = Is_Io(alpha1,settings) ;
		nset2 = Is_Io(alpha2,settings) ;

		if ( nset1 != set1 )
		{			
			if ( TRUE == nset1 && FALSE == set1 )	
				Add_Cache_Node( &Io_CACHE, alpha1 ) ; // insert into Io 
			if ( FALSE == nset1 && TRUE == set1 )
				Del_Cache_Node( &Io_CACHE, alpha1 ) ;
		}		
		if ( nset2 != set2 )
		{						
			if ( TRUE == nset2 && FALSE == set2 )		
				Add_Cache_Node( &Io_CACHE, alpha2 ) ; // insert into Io 						
			if ( FALSE == nset2 && TRUE == set2 )
				Del_Cache_Node( &Io_CACHE, alpha2 ) ;
		}

		
		 //Check_Alphas ( ALPHA, settings ) ;

		index = (int *)calloc(settings->pairs->count,sizeof(int)) ;
		if (NULL == index)
		{
			printf("\n FATAL ERROR : fail to malloc index.\n") ;
			system("pause");
			exit(1) ;
		}
		 //����bup  blow  ��ֵ
		for (loop = 1 ; loop < settings->pairs->classes ; loop ++)
		{
			alpha3 = ALPHA + settings->ij_up[loop-1] - 1 ;
			if (alpha3!=alpha1&&alpha3!=alpha2&&FALSE==Is_Io(alpha3,settings)) 
			{
				settings->bj_up[loop-1] += 
					- s1*(n1 - a1)*Calc_Kernel( alpha1, alpha3, settings ) 
					- s2*(n2 - a2)*Calc_Kernel( alpha2, alpha3, settings ) ;
				if (0==index[alpha3-ALPHA])
				{
					alpha3->f_cache +=  
						- s1*(n1 - a1)*Calc_Kernel( alpha1, alpha3, settings) 
						- s2*(n2 - a2)*Calc_Kernel( alpha2, alpha3, settings ) ;
					index[alpha3-ALPHA] = 1 ;
				}
			}
			else
			{
				settings->bj_up[loop-1] = INT_MAX ;
				settings->ij_up[loop-1] = 0 ;
			}
			alpha3 = ALPHA + settings->ij_low[loop-1] - 1 ;
			if (alpha3!=alpha1&&alpha2!=alpha3&&FALSE==Is_Io(alpha3,settings)) 
			{	
				settings->bj_low[loop-1] += 
					- s1*(n1 - a1)*Calc_Kernel( alpha1, alpha3, settings) 
					- s2*(n2 - a2)*Calc_Kernel( alpha2, alpha3, settings ) ;
				if (0==index[alpha3-ALPHA])
				{
					alpha3->f_cache +=  
						- s1*(n1 - a1)*Calc_Kernel( alpha1, alpha3, settings ) 
						- s2*(n2 - a2)*Calc_Kernel( alpha2, alpha3, settings) ;
					index[alpha3-ALPHA] = 1 ;
				}
			}
			else
			{
				settings->bj_low[loop-1] = INT_MIN ;
				settings->ij_low[loop-1] = 0 ;
			}
		}
		//���� i1  i2 ��ֵ  ��ѡ��b
		if ( FALSE==Is_Io(alpha1,settings) )
		{
			if (0==index[alpha1-ALPHA])
			{
				alpha1->f_cache = alpha1->f_cache 				
					- s1*(n1 - a1)*K11 - s2*(n2 - a2)*K12 ;
				index[alpha1-ALPHA] = 1 ;
			}
			alpha3 = alpha1 ;
			for (loop = 0 ; loop < settings->pairs->classes-1 ; loop ++)
			{
				if (alpha3->pair->target > (loop+1) )
				{
					//lower
					if (alpha3->setname[loop]==Io_b || alpha3->setname[loop]==I_One)
					{
						if (alpha3->f_cache-1<settings->bj_up[loop])
						{
							settings->bj_up[loop] = alpha3->f_cache-1 ;
							settings->ij_up[loop] = alpha3 - ALPHA + 1 ;
						}
					}
					if (alpha3->setname[loop]==Io_b || alpha3->setname[loop]==I_Fou)
					{
						if (alpha3->f_cache-1>settings->bj_low[loop])
						{
							settings->bj_low[loop] = alpha3->f_cache-1 ;
							settings->ij_low[loop] = alpha3 - ALPHA + 1 ;
						}
					}
				}
				else
				{
					//upper
					if (alpha3->setname[loop]==Io_a || alpha3->setname[loop]==I_Thr)
					{
						if (alpha3->f_cache+1<settings->bj_up[loop])
						{
							settings->bj_up[loop] = alpha3->f_cache+1 ;
							settings->ij_up[loop] = alpha3 - ALPHA + 1 ;
						}
					}
					if (alpha3->setname[loop]==Io_a || alpha3->setname[loop]==I_Two)
					{
						if (alpha3->f_cache+1>settings->bj_low[loop])
						{
							settings->bj_low[loop] = alpha3->f_cache+1 ;
							settings->ij_low[loop] = alpha3 - ALPHA + 1 ;
						}
					}
				}
			}		
		}
		if ( FALSE==Is_Io(alpha2,settings) )
		{
			if (0==index[alpha2-ALPHA])
			{
				alpha2->f_cache = alpha2->f_cache 			
					- s1*(n1 - a1)*K12 - s2*(n2 - a2)*K22 ;
				index[alpha2-ALPHA] = 1 ;
			}			
			alpha3 = alpha2 ;
			for (loop = 0 ; loop < settings->pairs->classes-1 ; loop ++)
			{
				if (alpha3->pair->target > (loop+1) )
				{
					//lower
					if (alpha3->setname[loop]==Io_b || alpha3->setname[loop]==I_One)
					{
						if (alpha3->f_cache-1<settings->bj_up[loop])
						{
							settings->bj_up[loop] = alpha3->f_cache-1 ;
							settings->ij_up[loop] = alpha3 - ALPHA + 1 ;
						}
					}
					if (alpha3->setname[loop]==Io_b || alpha3->setname[loop]==I_Fou)
					{
						if (alpha3->f_cache-1>settings->bj_low[loop])
						{
							settings->bj_low[loop] = alpha3->f_cache-1 ;
							settings->ij_low[loop] = alpha3 - ALPHA + 1 ;
						}
					}
				}
				else
				{
					//upper
					if (alpha3->setname[loop]==Io_a || alpha3->setname[loop]==I_Thr)
					{
						if (alpha3->f_cache+1<settings->bj_up[loop])
						{
							settings->bj_up[loop] = alpha3->f_cache+1 ;
							settings->ij_up[loop] = alpha3 - ALPHA + 1 ;
						}
					}
					if (alpha3->setname[loop]==Io_a || alpha3->setname[loop]==I_Two)
					{
						if (alpha3->f_cache+1>settings->bj_low[loop])
						{
							settings->bj_low[loop] = alpha3->f_cache+1 ;
							settings->ij_low[loop] = alpha3 - ALPHA + 1 ;
						}
					}
				}
			}		
		}
		//����֧��������ֵ ��ѡ��b
		cache = Io_CACHE.front ;
		while ( NULL != cache ) 
		{
			alpha3 = cache->alpha ;
			if (0==index[alpha3-ALPHA])
			{
				alpha3->f_cache = alpha3->f_cache 
					- s1*(n1 - a1)*Calc_Kernel( alpha1, alpha3, settings) 
					- s2*(n2 - a2)*Calc_Kernel( alpha2, alpha3, settings) ;
				//if(fabs(alpha3->f_cache-Calculate_Ordinal_Fi(alpha3-ALPHA+1,settings))>0.001)
				//{
				//	alpha3->f_cache=Calculate_Ordinal_Fi(alpha3-ALPHA+1,settings);
				//}
				index[alpha3-ALPHA] = 1 ;
			}
			//temp = Calculate_Ordinal_Fi(alpha3-ALPHA+1,settings) ;

			for (loop = 0 ; loop < settings->pairs->classes-1 ; loop ++)
			{
				if (cache->alpha->pair->target > (loop+1) )
				{
					//lower
					if (cache->alpha->setname[loop]==Io_b || cache->alpha->setname[loop]==I_One)
					{
						if (cache->alpha->f_cache-1<settings->bj_up[loop])
						{
							settings->bj_up[loop] = cache->alpha->f_cache-1 ;
							settings->ij_up[loop] = cache->alpha - ALPHA + 1 ;
						}
					}
					if (cache->alpha->setname[loop]==Io_b || cache->alpha->setname[loop]==I_Fou)
					{
						if (cache->alpha->f_cache-1>settings->bj_low[loop])
						{
							settings->bj_low[loop] = cache->alpha->f_cache-1 ;
							settings->ij_low[loop] = cache->alpha - ALPHA + 1 ;
						}
					}
				}
				else
				{
					//upper
					if (cache->alpha->setname[loop]==Io_a || cache->alpha->setname[loop]==I_Thr)
					{
						if (cache->alpha->f_cache+1<settings->bj_up[loop])
						{
							settings->bj_up[loop] = cache->alpha->f_cache+1 ;
							settings->ij_up[loop] = cache->alpha - ALPHA + 1 ;
						}
					}
					if (cache->alpha->setname[loop]==Io_a || cache->alpha->setname[loop]==I_Two)
					{
						if (cache->alpha->f_cache+1>settings->bj_low[loop])
						{
							settings->bj_low[loop] = cache->alpha->f_cache+1 ;
							settings->ij_low[loop] = cache->alpha - ALPHA + 1 ;
						}
					}
				}
			}
			cache = cache->next ;
		}
		 //end of if-else to update B_LOW & B_UP
		
		
		for (loop = 0 ; loop < settings->pairs->classes-1 ; loop ++)
		{
			settings->SumF[loop]=settings->SumF[loop]
					-s1*(n1 - a1)*settings->SumK[loop][i1-1]
					-s2*(n2 - a2)*settings->SumK[loop][i2-1];
		}
		for (loop = 0 ; loop < settings->pairs->classes-1 ; loop ++)
		{
			alpha3=(ALPHA+settings->pairs->truecount+loop);
			if (0==index[alpha3-ALPHA])
			{
				alpha3->f_cache +=  
					- s1*(n1 - a1)*Calc_Kernel( alpha1, alpha3, settings) 
					- s2*(n2 - a2)*Calc_Kernel( alpha2, alpha3, settings ) ;
				index[alpha3-ALPHA] = 1 ;
			}
			//if(fabs(alpha3->f_cache-Calculate_Ordinal_Fi(alpha3-ALPHA+1,settings))>0.001)
			//{
			//	alpha3->f_cache=Calculate_Ordinal_Fi(settings->pairs->truecount+loop+1,settings);
			//}
		}
		free(index) ;
		//for(loop=0;loop<settings->pairs->classes-1;loop++)
		//{
		//	if(settings->ij_low[loop]==0 )
		//	{
		//		for(loop1=loop+1;loop1<settings->pairs->classes-1;loop1++)
		//		{
		//			if(settings->ij_low[loop1]!=0 )
		//			{
		//				settings->ij_low[loop]=settings->ij_low[loop1];
		//				settings->bj_low[loop]=settings->bj_low[loop1];
		//				break;
		//			}
		//		}
		//		if(settings->ij_low[loop]==0 )
		//		{
		//			for(loop1=loop-1;loop1>=0;loop1--)
		//			{
		//				if(settings->ij_low[loop1]!=0 )
		//				{
		//					settings->ij_low[loop]=settings->ij_low[loop1];
		//					settings->bj_low[loop]=settings->bj_low[loop1];
		//					break;
		//				}
		//			}
		//		}

		//	}
		//	if(settings->ij_up[loop]==0 )
		//	{
		//		
		//		for(loop1=loop-1;loop1>=0;loop1--)
		//		{
		//			if(settings->ij_up[loop1]!=0 )
		//			{
		//				settings->ij_up[loop]=settings->ij_up[loop1];
		//				settings->bj_up[loop]=settings->bj_up[loop1];
		//				break;
		//			}
		//		}
		//		if(settings->ij_up[loop]==0 )
		//		{
		//			for(loop1=loop+1;loop1<settings->pairs->classes-1;loop1++)
		//			{
		//				if(settings->ij_up[loop1]!=0 )
		//				{
		//					settings->ij_up[loop]=settings->ij_up[loop1];
		//					settings->bj_up[loop]=settings->bj_up[loop1];
		//					break;
		//				}
		//			}
		//		}
		//	}
		//}
		for(loop=0;loop<settings->pairs->classes-1;loop++)
		{
			if(settings->ij_low[loop]==0 )
			{
				settings->ij_low[loop]=settings->ij_up[loop];
				settings->bj_low[loop]=settings->bj_up[loop];
			}
			if(settings->ij_up[loop]==0 )
			{
				settings->ij_up[loop]=settings->ij_low[loop];
				settings->bj_up[loop]=settings->bj_low[loop];
			}
		}
		for (loop = 1 ; loop < settings->pairs->classes ; loop ++)
		{
			if (0==settings->ij_up[loop-1]||0==settings->ij_low[loop-1])
			{
				 Check_Alphas ( ALPHA, settings ) ;
				 break;
			}
				
		}
		// update mu_bias
		for (loop = 1; loop < settings->pairs->classes; loop ++)
		{
			settings->bmu_low[loop-1]=settings->bj_low[loop-1] ;
			settings->imu_low[loop-1]=loop ;
			if (loop>1)
			{	
				// b_low^j=max{b_low^j-1,b_low^j}
				if (settings->bmu_low[loop-2]>settings->bmu_low[loop-1])
				{
					settings->bmu_low[loop-1]=settings->bmu_low[loop-2] ;
					settings->imu_low[loop-1]=settings->imu_low[loop-2] ;
				}
			}
		}
		for (loop = settings->pairs->classes-1; loop > 0; loop --)
		{
			settings->bmu_up[loop-1]=settings->bj_up[loop-1] ;
			settings->imu_up[loop-1]=loop ;
			if (loop<settings->pairs->classes-1)
			{
				// b_up^j=min{b_up^j,b_up^j+1}
				if (settings->bmu_up[loop-1]>settings->bmu_up[loop])
				{
					settings->bmu_up[loop-1]=settings->bmu_up[loop] ;
					settings->imu_up[loop-1]=settings->imu_up[loop] ;
				}			
			}
		}
		for (loop = 2; loop < settings->pairs->classes; loop ++)
		{
			if (settings->mu[loop-1]>EPS*EPS) 
			{
				if (settings->bmu_up[loop-1]>settings->bmu_up[loop-2])
				{
					settings->bmu_up[loop-1]=settings->bmu_up[loop-2] ;
					settings->imu_up[loop-1]=settings->imu_up[loop-2] ;
				}
				if (settings->bmu_low[loop-2]<settings->bmu_low[loop-1])
				{
					settings->bmu_low[loop-2]=settings->bmu_low[loop-1] ;
					settings->imu_low[loop-2]=settings->imu_low[loop-1] ;
				}
			}
		}
		
		return TRUE ;
	} // end of update 
	else
	{
		//printf("fail to update pairs %lu and %lu\n",i1,i2) ;
		return FALSE ;
	}
}
// end of ordinal_takestep.c

