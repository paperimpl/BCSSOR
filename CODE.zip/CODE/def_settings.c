/*******************************************************************************\

	def_settings.cpp in Sequential Minimal Optimization ver2.0
	
	implements initialization function for def_settings.
	
	Chu Wei Copyright(C) National Univeristy of Singapore
	Create on Jan. 16 2000 at Control Lab of Mechanical Engineering 
	Update on Aug. 23 2001 

\*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "smo.h"

/*******************************************************************************\

	def_Settings * Create_def_Settings ( char * filename ) 
	
	create and initialize the def_Settings structure 
	input:  the pointer to the name of Input Data File
	output: the pointer to the def_Settings structure

\*******************************************************************************/

def_Settings * Create_def_Settings ( char * filename ) 
{

	def_Settings * settings = NULL ;
	char * pstr = NULL ;
	unsigned int result = 0 ;
	char buf[LENGTH] = "" ;

	if (NULL == filename)
	{
		printf("\r\nFATAL ERROR : the input pointer is NULL.\r\n") ;
		return NULL ;
	}
	if (NULL == (settings = (def_Settings *)(malloc(sizeof(def_Settings)))))
	{
		printf("\r\nFATAL ERROR : fail to malloc def_settings.\r\n") ;
		return NULL ;
	}

	// set all elements as default values
	settings->inputfile = NULL ;
	settings->testfile = NULL ;
	settings->tol = DEF_TOL ;
	settings->kappa = DEF_KAPPA ;
	settings->eps = DEF_EPS ;
	settings->p = DEF_P ;
	settings->kernel = DEF_KERNEL ;
	settings->smo_display = DEF_DISPLAY ;

	settings->vc1=10;
	settings->vc2=1;
	settings->threshold=0.1;


	settings->normalized_input = DEF_NORMALIZEINPUT ;

	
	// save data file name in INPUTFILE
	if ( 0!=strlen(filename) && '-'!=filename[0] ) 
	{
		if ( NULL != INPUTFILE )
		{
			free( (void*) INPUTFILE ) ;
			INPUTFILE = NULL ;						
		}		
		if ( NULL == ( INPUTFILE = strdup(filename) ) )
		{
			// clear the structure before exit
			free (settings) ;
			printf("\r\nFATAL ERROR : fail to save the name of input file.\r\n") ;
			return NULL ;
		}
	}
	else
	{
		free (settings) ;
		return NULL ;
	}

	// if there is "train" in the file name of training data, such as "*train*.*",
	// test data set should be named as "*test*.*".
	// if we fail to find "train" in the training data file,
	// we just use the train data as test data.

	// create testing file name 
	pstr = strstr( INPUTFILE, "train" ) ;
	if (NULL == pstr)
		TESTFILE = strdup(filename) ;
	else
	{
		result = abs( INPUTFILE - pstr ) ;
		strncpy (buf, INPUTFILE, result ) ;
		buf[result] = '\0' ;
		strcat(buf, "test") ;
		strcat (buf, pstr+5) ;
		TESTFILE = strdup(buf) ;
	}
	
	Create_Data_List( &(settings->pairs) ) ;
	Create_Data_List( &(settings->testdata) ) ;
	Create_Data_List( &(settings->traindata) ) ;

	return settings ; 
}

BOOL Update_def_Settings( def_Settings * defsetting )
{
	char buf[LENGTH] ;
	char msg[20] ;
	BOOL batchgoon = TRUE ;
	char * pstr ;
	unsigned int sz = 0 ;	
	unsigned int serialno = 0 ;
	
	if (NULL == defsetting)
		return FALSE ;
		// load data into pairs 
	if ( FALSE == smo_Loadfile(&(defsetting->traindata), defsetting->inputfile, 0) )
	{	
		batchgoon = FALSE ;
		printf("Failed to load training data from the file %s\n", defsetting->inputfile) ;
	}

	return batchgoon ;	
}

/*******************************************************************************\

	void * Clear_def_Settings ( def_Settings * ptrSetting ) 
	
	Clear the def_Settings structure, including the unique copy of Data_List
	input:  the pointer to the def_Settings structure
	output:  none 

\*******************************************************************************/

void Clear_def_Settings( def_Settings * settings )
{
	if ( NULL != settings )
	{		
		if ( FALSE == Clear_Data_List( &(settings->pairs) ) )
			printf("\r\nFATAL ERROR : error happened in Clearing Data_List.\r\n") ;
		if ( FALSE == Clear_Data_List( &(settings->testdata) ) )
			printf("\r\nFATAL ERROR : error happened in Clearing Data_List.\r\n") ;
	        if (NULL!=settings->validation.featuretype)
        	        free(settings->validation.featuretype) ;
        	settings->validation.featuretype = NULL ;
        	if (NULL!=settings->training.featuretype)
                	free(settings->training.featuretype) ;
        	settings->training.featuretype = NULL ;
        	if (NULL!=settings->training.labelnum)
                	free(settings->training.labelnum) ;
        	settings->training.labelnum = NULL ;
        	if (NULL!=settings->validation.labelnum)
                	free(settings->validation.labelnum) ;
        	settings->validation.labelnum = NULL ;
        	if (NULL!=settings->training.labels)
                	free(settings->training.labels) ;
        	settings->training.labels = NULL ;
        	if (NULL!=settings->validation.labels)
                	free(settings->validation.labels) ;
        	settings->validation.labels = NULL ;

		if ( NULL != INPUTFILE )
			free( INPUTFILE ) ;	
		if ( NULL != TESTFILE )
			free( TESTFILE ) ;	
		free (settings) ;
		settings = NULL ;
	}
} 
BOOL Create_pairs(def_Settings * defsetting)
{
	unsigned int index = 0 ;
	Data_Node * pair= NULL,* node = NULL ;
	Data_List * pairs = NULL ;
	double * point,* xmean;
	double mean = 0 ;
	int dim=0,j=0,y=0,loop;
	pairs= &defsetting->pairs;
	
	dim=defsetting->traindata.dimen;
	if ( NULL == (pairs->x_mean = (double *)(malloc(dim*sizeof(double))) ) 
		|| NULL == (pairs->x_devi = (double *)(malloc(dim*sizeof(double))) ) 
		|| NULL == (xmean = (double *)(malloc(dim*sizeof(double))) ) )
	{		
		if (NULL != pairs->x_mean) 
			free(pairs->x_mean) ;
		if (NULL != pairs->x_devi) 
			free(pairs->x_devi) ;
		if (NULL != xmean)
			free(xmean) ;
		printf("Malloc failed ");
		system("pause");
		return FALSE ;
	}
	for ( j = 0; j < dim; j ++ )
		pairs->x_mean[j] = 0 ;
	for ( j = 0; j < dim; j ++ )
		pairs->x_devi[j] = 0 ;
	for ( j = 0; j < dim; j ++ )
		xmean[j] = 0 ;
	
	pair=defsetting->traindata.front;
	while(pair!=NULL)
	{
		y= pair->target;
		point=pair->point;
		if(TRUE==Add_Data_List( pairs, Create_Data_Node(index, point, y)))
		{
			//pairs->mean = (mean * (((double)(pairs->count)) - 1) + y )/ ((double)(pairs->count))  ;
			//pairs->deviation = pairs->deviation + (y-mean)*(y-mean) * ((double)(pairs->count)-1)/((double)(pairs->count));			
			//mean = pairs->mean ;	
			//for ( j=0; j<dim; j++ )
			//{
			//	pairs->x_mean[j] = (xmean[j] * (((double)(pairs->count)) - 1) + point[j] )/ ((double)(pairs->count))  ;
			//	pairs->x_devi[j] = pairs->x_devi[j] + (point[j]-xmean[j])*(point[j]-xmean[j]) * ((double)(pairs->count)-1)/((double)(pairs->count));			
			//	xmean[j] = pairs->x_mean[j] ;
			//}
			index++;
			pair=pair->next;
		}
		else
		{
			printf("Add_Data_List failed ");
			system("pause");
			return FALSE;
		}
	}
	pair=defsetting->testdata.front;
	while(pair!=NULL)
	{
		y=defsetting->pairs.classes;
		point=pair->point;
		if(TRUE==Add_Data_List( pairs, Create_Data_Node(index, point, y)))
		{
			//pairs->mean = (mean * (((double)(pairs->count)) - 1) + y )/ ((double)(pairs->count))  ;
			//pairs->deviation = pairs->deviation + (y-mean)*(y-mean) * ((double)(pairs->count)-1)/((double)(pairs->count));			
			//mean = pairs->mean ;	
			//for ( j=0; j<dim; j++ )
			//{
			//	pairs->x_mean[j] = (xmean[j] * (((double)(pairs->count)) - 1) + point[j] )/ ((double)(pairs->count))  ;
			//	pairs->x_devi[j] = pairs->x_devi[j] + (point[j]-xmean[j])*(point[j]-xmean[j]) * ((double)(pairs->count)-1)/((double)(pairs->count));			
			//	xmean[j] = pairs->x_mean[j] ;
			//}
			index++;
			pair=pair->next;
		}
		else
		{
			printf("Add_Data_List failed ");
			system("pause");
			return FALSE;
		}
	}
	pair=defsetting->testdata.front;
	while(pair!=NULL)
	{
		y=1;
		point=pair->point;
		if(TRUE==Add_Data_List( pairs, Create_Data_Node(index, point, y)))
		{
			//pairs->mean = (mean * (((double)(pairs->count)) - 1) + y )/ ((double)(pairs->count))  ;
			//pairs->deviation = pairs->deviation + (y-mean)*(y-mean) * ((double)(pairs->count)-1)/((double)(pairs->count));			
			//mean = pairs->mean ;	
			//for ( j=0; j<dim; j++ )
			//{
			//	pairs->x_mean[j] = (xmean[j] * (((double)(pairs->count)) - 1) + point[j] )/ ((double)(pairs->count))  ;
			//	pairs->x_devi[j] = pairs->x_devi[j] + (point[j]-xmean[j])*(point[j]-xmean[j]) * ((double)(pairs->count)-1)/((double)(pairs->count));			
			//	xmean[j] = pairs->x_mean[j] ;
			//}
			index++;
			pair=pair->next;
		}
		else
		{
			printf("Add_Data_List failed ");
			system("pause");
			return FALSE;
		}
	}

	//pairs->deviation = sqrt( pairs->deviation / ((double)(pairs->count - 1.0)) ) ;
	//for ( j=0; j<dim; j++ )
	//	pairs->x_devi[j] = sqrt( pairs->x_devi[j] / ((double)(pairs->count - 1.0)) ) ;	
	node = pairs->front ;
	if ( TRUE == defsetting->normalized_input )
	{
		while ( node != NULL )
		{
		
			for ( j=0; j<dim; j++ )
			{				
				if (pairs->x_devi[j]>0)
					node->point[j] = (node->point[j]-pairs->x_mean[j])/(pairs->x_devi[j]) ;
				else
					node->point[j] = 0 ;
			}
			node = node->next ; 
		}
	}

	for(loop=0;loop<defsetting->pairs.classes-1;loop++)
	{
		point= (double *) calloc(defsetting->pairs.dimen,sizeof(double));
		if(FALSE==Add_Data_List(& defsetting->pairs, Create_Data_Node(index, point, defsetting->pairs.classes)))
		{
			printf("Add_Data_List failed ");
			system("pause");
			return FALSE;
		}
		index++;
	}

	return TRUE;
}
// end of def_settings.c

