/*******************************************************************************\

	loadfile.c in Sequential Minimal Optimization ver2.0 
	
	loads data file from disk in data list.

	Chu Wei Copyright(C) National Univeristy of Singapore
	Create on Jan. 16 2000 at Control Lab of Mechanical Engineering 
	Update on Aug. 23 2001 

\*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <limits.h>
#include "smo.h"

/*******************************************************************************\

	BOOL smo_Loadfile ( Pairs * pairs, char * filename, unsigned int inputdim ) 
	
	load data file settings->inputfile, and create the data list Pairs 
	input:  the pointers to pairs and filename
	output: 0 or 1

\*******************************************************************************/

BOOL smo_Loadfile ( Data_List * pairs, char * inputfilename, int inputdim ) 
{ 

	FILE * smo_stream ;
	FILE * smo_target = NULL ;
	char * pstr = NULL ;
	char buf[LENGTH/2],buf1[LENGTH/2] ;
	int distance=0,loop=0,loop1=0,lenbuf;
	char * temp ;
	int dim = -2 ;
	unsigned long index = 1 ;
	unsigned int result, sz ;
	int var = 0, chg = 0 ;
	float * point = NULL ;
	unsigned int y ;
	int i = 0, j = 0 ;
	double mean = 0 ;
	double ymax = LONG_MIN ;
	double ymin = LONG_MAX ;
	double * xmean = NULL;
	Data_Node * node = NULL ;
	int t0=0, tr=0 ;
	FILE * fid ;

	Data_List label ;

	if ( NULL == pairs || NULL == inputfilename )
		return FALSE ;
	
	Clear_Data_List( pairs ) ;
	Create_Data_List( &label ) ;

	if( (smo_stream = fopen( inputfilename, "r+t" )) == NULL )
	{
		//printf( "can not open the file %s.\n", inputfilename );
		return FALSE ;
	}
	
	// save file name 
	var = strlen( inputfilename ) ;
	if (NULL != pairs->filename) 
		free(pairs->filename) ;
	pairs->filename = (char*)malloc((var+1)*sizeof(char)) ;
	if (NULL == pairs->filename)
	{
		printf("fail to malloc for pairs->filename.\n") ;
		exit(0) ;
	}
	strncpy(pairs->filename,inputfilename,var) ;
	pairs->filename[var]='\0' ;

	// check the input dimension here

	if ( NULL == fgets( buf, LENGTH, smo_stream ))
	{
		printf( "fgets error in reading the first line.\n" );
		fclose( smo_stream );
		return FALSE ;
	}
	
	var = strlen( buf ) ;
	lenbuf= strlen( buf );
	for(loop=0;loop<=lenbuf;loop++)
		buf1[loop]=buf[loop];
	distance=0;
	if (var >= LENGTH-1) 
	{
		printf( "the line is too long in the file %s.\n", inputfilename );
		fclose( smo_stream );
		return FALSE ;
	}
	
	if (0 < var)
	{		
		do 
		{
			dim = dim + 1 ;
			strtod( buf, &temp ) ;
			//strcpy( buf, temp ) ;
			distance+=temp-buf;
			lenbuf=strlen(buf1);
			for(loop=0,loop1=distance;loop1<=lenbuf;loop++,loop1++)
			{
				buf[loop]=buf1[loop1];
			}
			chg = var - strlen(buf) ;
			var = var - chg ;
		}
		while ( 0 != chg ) ;
	}
	else
	{ 
		fclose( smo_stream );
		printf("the first line in the file is empty.\n") ;
		return FALSE ;
	}

	if ( 0 > dim || (0 == dim && 0 == inputdim) ) 
	{
		fclose( smo_stream );
		printf( "input dimension is less than one.\n") ;
		return FALSE ;
	}

	if (inputdim > 0)
	{
		if (inputdim == dim + 1 ) // test file without target
		{
			// try to open "*target*.*" as target
			// create target file name
			pstr = strstr( inputfilename , "test" ) ;
			if (NULL != pstr)
			{
				result = abs( inputfilename - pstr ) ;
				strncpy (buf, inputfilename, result ) ;
				buf[result] = '\0' ;
				strcat(buf, "targets") ;
				strcat (buf, pstr+4) ;
				smo_target = fopen( buf, "r+t" ) ;
			}
			dim = inputdim ;
			pairs->dimen = dim ;
		}
		else if ( inputdim != dim )
		{
			printf("Dimensionality in testdata is inconsistent with traindata.\n") ;
			return FALSE ;
		}
		else
			pairs->dimen = dim ;
	}
	else
		pairs->dimen = dim ;
	
	//initialize the x_mean and x_devi in Data_List pairs

	// begin to initialize data_list for digital input only
	printf("\nLoading %s ...  \n", inputfilename) ;
	pairs->datatype = CLASSIFICATION ; 

	rewind( smo_stream ) ;
	fgets( buf, LENGTH, smo_stream ) ;
	do
	{
		distance=0;
		lenbuf=strlen( buf );
		for(loop=0;loop<=lenbuf;loop++)
			buf1[loop]=buf[loop];

#ifdef SMO_DEBUG 
		printf("%d\n", index) ;
		printf("%s\n\n\n", buf) ;
#endif
		point = (float *) malloc( (dim+1) * sizeof(float) ) ; // Pairs to free them
		if ( NULL == point )
		{
			printf("not enough memory.\n") ;
			if (NULL != smo_target)
				fclose( smo_target ) ;
			if (NULL != smo_stream)
				fclose( smo_stream );
			Clear_Data_List( pairs ) ;
			return FALSE ;
		}
		var = strlen( buf ) ;	
		i = 0 ;
		chg = dim ;

		while ( chg>0 && i<dim)
		{
			point[i] = strtod( buf, &temp ) ;
			i++ ;
			distance+=temp-buf;
			lenbuf=strlen(buf1);
			for(loop=0,loop1=distance;loop1<=lenbuf;loop++,loop1++)
			{
				buf[loop]=buf1[loop1];
			}
			//strcpy( buf, temp ) ;
			chg = var - strlen(buf) ;
			var = var - chg ;
		}
		point[dim]=0 ;
		if (i==dim && chg>0 && var>0)
			y = (unsigned int)strtod( buf, &temp ) ;
		else
		{
			free(point) ;
			y = 0 ;
			printf("Warning: the input file %s contains a blank or defective line.\n",inputfilename) ;
 			system("pause");
			exit(1) ;
		}
		// load y as target from other file when dim+1
		if (NULL != smo_target)
		{
			if ( NULL != fgets( buf, LENGTH, smo_target ) )
			{
				var = strlen( buf ) ;
				y = (int)strtod( buf, &temp ) ;
				strcpy( buf, temp ) ;
				chg = var - strlen(buf) ;
				if (0==chg)
					printf("Warning: the target file contains a blank line.\n") ;
			}
			else
				printf("Warning: the target file is shorter than the input file.\n") ;
		}

		/*	for ( i = 0; i < dim; i ++ )
			{
				point[i] = strtod( buf, &temp ) ;
				strcpy( buf, temp ) ;
			}
			y = strtod( buf, &temp ) ;

			// load y as target from other file when dim+1
			if (NULL != smo_target)
			{
				fgets( buf, LENGTH, smo_target ) ;
				y = strtod( buf, &temp ) ;
			}*/

		if (chg>0) 
		{	
						
			if ( TRUE == Add_Data_List( pairs, Create_Data_Node(index, point, y) ) )
			{
				// update statistics
				Add_Label_Data_List( &label, Create_Data_Node(index, point, y) ) ;
				index ++ ;
			}
			else
			{
				printf("%d\n", index) ;
				printf("duplicate data \n") ;
			}
		}
	}
	while( !feof( smo_stream ) && NULL != fgets( buf, LENGTH, smo_stream ) ) ;

	if (label.count>=2||inputdim>0)
		pairs->datatype = ORDINAL ;
	else
	{
		printf("Warning : not a ordinal regression.\n") ;
		system("pause");
		exit(1) ;
	}

	if (pairs->count < MINNUM || (pairs->datatype == UNKNOWN && inputdim == 0 ) ) 
	{
		printf("too few input pairs\n") ;
		Clear_Data_List( pairs ) ;
		if (NULL != smo_target)
			fclose( smo_target ) ;
		if (NULL != smo_stream)
			fclose( smo_stream );
		return FALSE ;
	}

	printf("Total %d samples with %d dimensions for ", (int)pairs->count, (int)pairs->dimen) ;	

	if	(inputdim > 0)
		printf("TESTING.\r\n") ;
	else 
	{
		if( CLASSIFICATION == pairs->datatype )
			printf("CLASSIFICATION.\r\n") ;
		else if ( ORDINAL == pairs->datatype )
		{
			printf("ORDINAL %lu REGRESSION.\r\n",label.count) ;
			pairs->classes = label.count ;
			if (NULL != pairs->labels)
				free( pairs->labels ) ;
			i=0;
			pairs->labels = (unsigned int*)malloc(pairs->classes*sizeof(unsigned int)) ;
			pairs->labelnum = (unsigned int*)malloc(pairs->classes*sizeof(unsigned int)) ;
			if (NULL != pairs->labels&&NULL != pairs->labelnum)
			{
				node = label.front ;
				j=0 ;				
				printf("ordinal varibles : ") ;
				while (NULL!=node)
				{
					if (node->target<1 || node->target>pairs->classes)
					{
						printf("Error : targets should be from 1 to %d.\n",(int)pairs->classes) ;
						system("pause");
						exit(1) ;
					}
					pairs->labels[node->target-1] = node->target ;
					if (node->target-1==0)
						t0 = node->target ;
					if (node->target==(int)pairs->classes)
						tr = node->target ;
					pairs->labelnum[node->target-1] = node->fold ;
					i += node->fold ;
					printf("%d(%d)  ", node->target, node->fold) ;
					node = node->next ;
				}
				printf("\n") ;
				if (i!=(int)pairs->count||t0!=1||tr!=(int)pairs->classes)
				{
					printf("Error in data list.\n") ;
					system("pause");
					exit(1) ;
				}
			}
			else
			{
				printf("fail to malloc for pairs->labels.\n") ;			
				system("pause");
				exit(1) ;
			}
		}
		else 
			printf("UNKNOWN.\r\n") ;
	}


	Clear_Label_Data_List (&label) ;
	if (NULL != smo_target)
		fclose( smo_target ) ;
	if (NULL != smo_stream)
		fclose( smo_stream );
	if ( NULL != xmean )
		free( xmean ) ;
	return TRUE ;
}
// end of loadfile.c

